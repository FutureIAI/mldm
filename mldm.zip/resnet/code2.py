import os
import copy
import time
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import torch
from torch import nn, optim
from torch.utils.data import DataLoader
from torchvision import transforms, models
from torchvision.datasets import ImageFolder
from torch.optim.lr_scheduler import ReduceLROnPlateau

# #################### 配置参数 ####################
config = {
    "data_dir": "./dataset",  # 数据集路径
    "model_type": "resnet50",  # 使用ResNet50模型
    "pretrained": True,  # 使用预训练权重
    "batch_size": 32,  # 批处理大小
    "num_epochs": 30,  # 总训练轮次
    "initial_lr": 0.001,  # 初始学习率
    "weight_decay": 1e-4,  # L2正则化
    "patience": 5,  # 早停等待轮次
    "num_classes": 4,  # 分类类别数
    "device": torch.device("cuda" if torch.cuda.is_available() else "cpu")
}


# #################### 数据预处理 ####################
def create_datasets():
    # 训练集增强策略
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(224, scale=(0.6, 1.0)),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.RandomVerticalFlip(p=0.2),
        transforms.ColorJitter(brightness=0.2, contrast=0.2),
        transforms.RandomRotation(25),
        transforms.GaussianBlur(kernel_size=3),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    # 验证集标准化处理
    val_transform = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    # 创建数据集
    train_data = ImageFolder(
        root=os.path.join(config["data_dir"], "train"),
        transform=train_transform
    )
    val_data = ImageFolder(
        root=os.path.join(config["data_dir"], "test"),  # 建议使用val目录
        transform=val_transform
    )

    return train_data, val_data


# #################### 模型构建 ####################
def initialize_model():
    # 加载预训练模型
    model = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V2)

    # 冻结所有卷积层参数
    if config["pretrained"]:
        for param in model.parameters():
            param.requires_grad = False

    # 替换分类头
    in_features = model.fc.in_features
    model.fc = nn.Sequential(
        nn.Linear(in_features, 1024),
        nn.ReLU(),
        nn.BatchNorm1d(1024),
        nn.Dropout(0.5),
        nn.Linear(1024, config["num_classes"])
    )

    # 选择性解冻最后两个stage
    for name, param in model.named_parameters():
        if "layer3" in name or "layer4" in name:
            param.requires_grad = True

    return model.to(config["device"])


# #################### 训练函数 ####################
def train_model(model, dataloaders, criterion, optimizer):
    best_model_wts = copy.deepcopy(model.state_dict())
    best_acc = 0.0
    history = {'train_loss': [], 'val_acc': []}

    scheduler = ReduceLROnPlateau(
        optimizer,
        mode='max',
        factor=0.1,
        patience=2,
        verbose=True
    )

    for epoch in range(config["num_epochs"]):
        print(f'Epoch {epoch + 1}/{config["num_epochs"]}')
        print('-' * 10)

        # 训练阶段
        model.train()
        running_loss = 0.0
        for inputs, labels in dataloaders['train']:
            inputs = inputs.to(config["device"])
            labels = labels.to(config["device"])

            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item() * inputs.size(0)

        epoch_loss = running_loss / len(dataloaders['train'].dataset)
        history['train_loss'].append(epoch_loss)

        # 验证阶段
        model.eval()
        correct = 0
        total = 0
        with torch.no_grad():
            for inputs, labels in dataloaders['val']:
                inputs = inputs.to(config["device"])
                labels = labels.to(config["device"])

                outputs = model(inputs)
                _, preds = torch.max(outputs, 1)

                total += labels.size(0)
                correct += (preds == labels).sum().item()

        epoch_acc = 100 * correct / total
        history['val_acc'].append(epoch_acc)

        # 学习率调整
        scheduler.step(epoch_acc)

        # 保存最佳模型
        if epoch_acc > best_acc:
            best_acc = epoch_acc
            best_model_wts = copy.deepcopy(model.state_dict())
            torch.save(model.state_dict(), 'best_resnet50.pth')

        print(f'Train Loss: {epoch_loss:.4f} | Val Acc: {epoch_acc:.2f}%')
        print('-' * 20)

    # 加载最佳模型权重
    model.load_state_dict(best_model_wts)
    return model, history


# #################### 可视化与预测 ####################
def visualize_results(history):
    plt.figure(figsize=(12, 5))

    plt.subplot(1, 2, 1)
    plt.plot(history['train_loss'], label='Training Loss')
    plt.title('Training Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()

    plt.subplot(1, 2, 2)
    plt.plot(history['val_acc'], label='Validation Accuracy')
    plt.title('Validation Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy (%)')
    plt.legend()

    plt.tight_layout()
    plt.show()


def predict_image(model, image_path):
    transform = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    img = Image.open(image_path).convert('RGB')
    img_tensor = transform(img).unsqueeze(0).to(config["device"])

    model.eval()
    with torch.no_grad():
        outputs = model(img_tensor)
        probs = torch.nn.functional.softmax(outputs, dim=1)
        conf, preds = torch.max(probs, 1)

    plt.figure(figsize=(10, 5))
    plt.subplot(1, 2, 1)
    plt.imshow(img)
    plt.title(f'Predicted: {dataloaders["val"].dataset.classes[preds[0]]}\nConfidence: {conf[0]:.2f}')
    plt.axis('off')

    plt.subplot(1, 2, 2)
    plt.barh(dataloaders["val"].dataset.classes, probs.cpu().numpy()[0])
    plt.xlabel('Probability')
    plt.tight_layout()
    plt.show()


# #################### 主程序 ####################
if __name__ == "__main__":
    # 初始化数据集
    train_data, val_data = create_datasets()

    # 创建数据加载器
    dataloaders = {
        "train": DataLoader(
            train_data,
            batch_size=config["batch_size"],
            shuffle=True,
            pin_memory=True
        ),
        "val": DataLoader(
            val_data,
            batch_size=config["batch_size"],
            shuffle=False,
            pin_memory=True
        )
    }

    # 初始化模型
    model = initialize_model()
    print(f"Using {config['model_type']} on {config['device']}")

    # 设置损失函数和优化器
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(
        filter(lambda p: p.requires_grad, model.parameters()),
        lr=config["initial_lr"],
        weight_decay=config["weight_decay"]
    )

    # 开始训练
    trained_model, history = train_model(
        model,
        dataloaders,
        criterion,
        optimizer
    )

    # 可视化结果
    visualize_results(history)

    # 示例预测
    if os.path.exists("img.png"):
        predict_image(trained_model, "img.png")