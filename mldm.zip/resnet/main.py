import torch
import torchvision
print(torch.__version__)        # 应输出 1.12.1+
print(torchvision.__version__) # 应输出 0.13.1+
print(torchvision.models.efficientnet_v2_s) # 不再报错