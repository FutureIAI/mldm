import os
import torch
import torchvision
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

from torchvision import models, datasets, transforms
import torch.utils.data as tud
import numpy as np
from torch.utils.data import Dataset, DataLoader, SubsetRandomSampler
from PIL import Image
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings("ignore")

device = torch.device("cuda:0" if torch.cuda.is_available() else 'cpu')
n_classes = 4  # 四分类任务
pretrained = True  # 修正变量名和布尔值
epochs = 20 # 训练轮次

# 训练集数据增强
train_transform = transforms.Compose([
    transforms.RandomResizedCrop(224),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])
traindataset = datasets.ImageFolder(root='./dataset/train/', transform=train_transform)

# 测试集确定性变换
test_transform = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])
testdataset = datasets.ImageFolder(root='./dataset/test/', transform=test_transform)

classes = testdataset.classes
print("类别列表:", classes)

# 模型定义
model = models.resnet18(pretrained=pretrained)
if pretrained:
    for param in model.parameters():
        param.requires_grad = False
model.fc = nn.Linear(model.fc.in_features, n_classes)  # 自动获取输入特征数
model = model.to(device)


# 训练函数
def train_model(model, train_loader, loss_fn, optimizer, epoch):
    model.train()
    total_loss, total_correct, total = 0., 0., 0.
    for inputs, labels in train_loader:
        inputs, labels = inputs.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = loss_fn(outputs, labels)
        loss.backward()
        optimizer.step()

        preds = outputs.argmax(dim=1)
        total_correct += preds.eq(labels).sum().item()
        total_loss += loss.item() * inputs.size(0)
        total += labels.size(0)

    avg_loss = total_loss / total
    acc = 100. * total_correct / total
    print(f"轮次: {epoch + 1:2d} | 训练损失: {avg_loss:.5f} | 训练准确率: {acc:.2f}%")
    return avg_loss, acc


# 测试函数
def test_model(model, test_loader, loss_fn, epoch):
    model.eval()  # 切换为评估模式
    total_loss, total_correct, total = 0., 0., 0.
    with torch.no_grad():
        for inputs, labels in test_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            loss = loss_fn(outputs, labels)

            preds = outputs.argmax(dim=1)
            total_correct += preds.eq(labels).sum().item()
            total_loss += loss.item() * inputs.size(0)
            total += labels.size(0)

    avg_loss = total_loss / total
    acc = 100. * total_correct / total
    print(f"轮次: {epoch + 1:2d} | 测试损失: {avg_loss:.5f} | 测试准确率: {acc:.2f}%")
    return avg_loss, acc


# 优化器与损失函数
loss_fn = nn.CrossEntropyLoss().to(device)
optimizer = optim.Adam(model.fc.parameters(), lr=0.0001) if pretrained else optim.Adam(model.parameters(), lr=0.0001)
train_loader = DataLoader(traindataset, batch_size=32, shuffle=True)
test_loader = DataLoader(testdataset, batch_size=32, shuffle=False)  # 测试集不需要shuffle

# 训练循环
for epoch in range(epochs):
    train_loss, train_acc = train_model(model, train_loader, loss_fn, optimizer, epoch)
    test_loss, test_acc = test_model(model, test_loader, loss_fn, epoch)

# 预测部分
model.eval()
path = 'img.png'  # 确保图片路径正确
transform = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

img = Image.open(path).convert('RGB')  # 确保读取RGB格式
img_tensor = transform(img).unsqueeze(0).to(device)

with torch.no_grad():
    output = model(img_tensor)
    probabilities = F.softmax(output, dim=1).cpu().numpy()[0]

pred_class = output.argmax().item()
plt.imshow(img)
plt.axis('off')
plt.title(f'预测类别: {classes[pred_class]}')
plt.show()

# 四分类概率输出
print(f"图像预测类别: {classes[pred_class]}")
for i, (cls, prob) in enumerate(zip(classes, probabilities)):
    print(f"类别 {cls}: {prob * 100:.2f}%")