import warnings
import argparse
import torch
from datasets.data_builder import build_dataloader
from easydict import EasyDict
import yaml
import os
from utils.misc_helper import get_current_time,create_logger,set_seed,AverageMeter,save_checkpoint,summary_model
from models.model_helper import ModelHelper
from utils.optimizer_helper import get_optimizer
from utils.criterion_helper import build_criterion
from utils.eval_helper import performances,log_metrics
import logging
import numpy as np
import pprint
from utils.dist_helper import setup_distributed
from torch.nn.parallel import DistributedDataParallel as DDP
import torch.distributed as dist
from utils.categories import Categories


warnings.filterwarnings('ignore')
parser = argparse.ArgumentParser(description="train RealNet")
parser.add_argument("--config", default="experiments/{}/net.yaml")
parser.add_argument("--dataset", default="MVTec-AD",choices=['MVTec-AD','BTAD'])
parser.add_argument("--local_rank", default=-1, type=int)

parser.add_argument("--class_name", default="bottle",choices=[
        # mvtec-ad
        "bottle",
        "cable",
        "capsule",
        "carpet",
        "grid",
        "hazelnut",
        "leather",
        "metal_nut",
        "pill",
        "screw",
        "tile",
        "toothbrush",
        "transistor",
        "wood",
        "zipper",
        # btad
         "01",
         "02",
         "03",
        ] )


def update_config(config, args):
    """更新配置参数"""
    # 提取网络结构中的所有层索引
    layers = []
    for block in config.structure:
        layers.extend([layer.idx for layer in block.layers])
    # 去重并排序
    layers = list(set(layers))
    layers.sort()

    # 更新网络配置
    config.net[0].kwargs['outlayers'] = layers  # 设置输出层
    config.net[1].kwargs = config.net[1].get('kwargs', {})  # 确保kwargs存在
    config.net[1].kwargs['structure'] = config.structure  # 设置网络结构
    
    # 更新数据集路径中的占位符
    config.dataset.train.meta_file = config.dataset.train.meta_file.replace("{}", args.class_name)
    config.dataset.test.meta_file = config.dataset.test.meta_file.replace("{}", args.class_name)
    config.dataset.train.sdas_dir = config.dataset.train.sdas_dir.replace("{}", args.class_name)
    
    return config


def main():
    # 解析命令行参数
    args = parser.parse_args()
    
    # 获取当前数据集的所有类别
    class_name_list = Categories[args.dataset]
    # 确保指定的类别在数据集中存在
    assert args.class_name in class_name_list
    
    # 格式化配置文件路径
    args.config = args.config.format(args.dataset)
    
    # 加载YAML配置文件
    with open(args.config) as f:
        config = EasyDict(yaml.load(f, Loader=yaml.FullLoader))
    
    # 设置分布式训练环境
    rank, world_size = setup_distributed()
    
    # 设置随机种子确保结果可复现
    set_seed(config.random_seed)
    # 更新配置参数
    config = update_config(config, args)
    
    # 设置实验路径和保存目录
    config.exp_path = os.path.dirname(args.config)
    config.checkpoints_path = os.path.join(config.exp_path, config.saver.checkpoints_dir)
    config.log_path = os.path.join(config.exp_path, config.saver.log_dir)
    
    # 主进程创建必要目录和日志
    if rank == 0:
        os.makedirs(config.checkpoints_path, exist_ok=True)
        os.makedirs(config.log_path, exist_ok=True)
        
        current_time = get_current_time()
        
        # 创建类别特定的日志记录器
        logger = create_logger(
            "net_logger_{}".format(args.class_name),  # 修改为net_logger
            config.log_path + "/net_{}_{}.log".format(args.class_name, current_time)  # 修改为net
        )
        
        # 记录配置信息
        logger.info("args: {}".format(pprint.pformat(args)))
        logger.info("config: {}".format(pprint.pformat(config)))
        logger.info("class name is : {}".format(args.class_name))
    
    # 创建数据加载器
    train_loader, val_loader = build_dataloader(config.dataset, distributed=True)
    
    # 获取本地GPU编号
    local_rank = int(os.environ["LOCAL_RANK"])
    
    # 创建模型
    model = ModelHelper(config.net)
    model.cuda()  # 转移到GPU
    
    # 主进程打印模型摘要
    if rank == 0:
        summary_model(model, logger)
    
    # 初始化自适应特征选择(AFS)索引
    model.afs.init_idxs(model, train_loader, distributed=True)
    # 转换为同步批归一化（分布式训练专用）
    model = torch.nn.SyncBatchNorm.convert_sync_batchnorm(model)
    
    # 使用分布式数据并行包装模型
    model = DDP(
        model,
        device_ids=[local_rank],
        output_device=local_rank,
        find_unused_parameters=True,  # 允许有未使用的参数
    )
    
    # 提取网络层信息
    layers = []
    for module in config.net:
        layers.append(module["name"])
    
    # 获取冻结层和激活层
    frozen_layers = model.module.frozen_layers
    active_layers = [layer for layer in layers if layer not in frozen_layers]
    
    # 主进程记录层信息
    if rank == 0:
        logger.info("layers: {}".format(layers))
        logger.info("frozen layers: {}".format(frozen_layers))
        logger.info("active layers: {}".format(active_layers))
    
    # 设置优化器参数（仅优化激活层）
    parameters = [
        {"params": getattr(model.module, layer).parameters()} for layer in active_layers
    ]
    
    # 创建优化器
    optimizer = get_optimizer(parameters, config.trainer.optimizer)
    
    # 获取关键评估指标
    key_metric = config.evaluator["key_metric"]
    
    # 初始化最佳指标
    best_metric = 0
    last_epoch = 0
    
    # 创建损失函数
    criterion = build_criterion(config.criterion)
    
    # 训练循环
    for epoch in range(last_epoch, config.trainer.max_epoch):
        # 当前epoch开始时的迭代步数
        last_iter = epoch * len(train_loader)
        # 设置数据加载器的epoch（分布式训练需要）
        train_loader.sampler.set_epoch(epoch)
        
        # 训练一个epoch
        train_one_epoch(
            config,
            train_loader,
            model,
            optimizer,
            epoch,
            last_iter,
            criterion,
            args.class_name
        )
        
        # 定期验证模型性能
        if (epoch + 1) % config.trainer.val_freq_epoch == 0:
            # 验证阶段
            ret_metrics = validate(config, val_loader, model, epoch + 1, args.class_name)
            
            # 主进程处理验证结果
            if rank == 0:
                # 计算关键指标的平均值
                ret_key_metric = np.mean([ret_metrics[key] for key in ret_metrics if key.find(key_metric) != -1])
                
                # 检查是否是最佳结果
                is_best = ret_key_metric >= best_metric
                best_metric = max(ret_key_metric, best_metric)
                
                # 如果是当前最佳结果，记录指标
                if is_best:
                    best_record = {key.replace("mean", 'best'): ret_metrics[key] for key in ret_metrics if key.find("mean") != -1}
                
                # 更新指标记录
                ret_metrics.update(best_record)
                # 记录指标
                log_metrics(ret_metrics, config.evaluator.metrics, "net_logger_{}".format(args.class_name))  # 修改为net_logger
                
                # 保存最佳模型
                if is_best:
                    save_checkpoint(
                        {
                            "epoch": epoch + 1,
                            "arch": config.net,
                            "state_dict": model.module.state_dict(),  # 保存模型状态
                            "best_metric": best_metric,
                        },
                        config,
                        args.class_name,
                    )
            
            # 分布式同步点
            dist.barrier()


def train_one_epoch(
    config,
    train_loader,
    model,
    optimizer,
    epoch,
    start_iter,
    criterion,
    class_name
):
    """训练一个epoch"""
    # 获取分布式训练信息
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    
    # 获取类别特定的日志记录器
    if rank == 0:
        logger = logging.getLogger("net_logger_{}".format(class_name))  # 修改为net_logger
    
    # 初始化损失记录器
    losses = AverageMeter(config.trainer.print_freq_step)
    # 设置为训练模式
    model.train()
    
    # 遍历训练数据
    for i, input in enumerate(train_loader):
        # 当前总迭代步数
        curr_step = start_iter + i
        
        # 模型前向传播
        outputs = model(input, train=True)
        
        # 计算损失
        loss = []
        for name, criterion_loss in criterion.items():
            weight = criterion_loss.weight
            loss.append(weight * criterion_loss(outputs))
        
        # 总损失
        loss = torch.sum(torch.stack(loss))
        
        # 分布式训练中的损失聚合
        reduced_loss = loss.clone()
        dist.all_reduce(reduced_loss)
        reduced_loss = reduced_loss / world_size
        losses.update(reduced_loss.item())  # 更新损失记录
        
        # 反向传播
        optimizer.zero_grad()
        loss.backward()
        
        # 梯度裁剪 (防止梯度爆炸)
        if config.trainer.get("clip_max_norm", None):
            max_norm = config.trainer.clip_max_norm
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm)
        
        # 参数更新
        optimizer.step()
        
        # 主进程定期打印训练信息
        if rank == 0 and (curr_step + 1) % config.trainer.print_freq_step == 0:
            logger.info(
                "Epoch: [{0}/{1}]\t"
                "Iter: [{2}/{3}]\t"
                "Loss {loss.val:.5f} ({loss.avg:.5f})\t"
                .format(
                    epoch + 1,
                    config.trainer.max_epoch,
                    curr_step + 1,
                    len(train_loader) * config.trainer.max_epoch,
                    loss=losses,
                )
            )


def validate(config, val_loader, model, epoch, class_name):
    """模型验证"""
    # 获取分布式训练信息
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    
    # 设置为评估模式
    model.eval()
    losses = []
    
    # 获取类别特定的日志记录器
    if rank == 0:
        logger = logging.getLogger("net_logger_{}".format(class_name))  # 修改为net_logger
    
    # 创建损失函数
    criterion = build_criterion(config.criterion)
    
    # 初始化预测和真实标签容器
    preds = []  # 异常分数预测
    masks = []  # 真实异常掩码
    
    # 禁用梯度计算
    with torch.no_grad():
        # 遍历验证数据
        for i, input in enumerate(val_loader):
            # 模型前向传播
            outputs = model(input, train=False)
            
            # 收集预测结果
            preds.append(outputs["anomaly_score"])
            masks.append(outputs["mask"])
            
            # 计算损失
            loss = []
            for name, criterion_loss in criterion.items():
                weight = criterion_loss.weight
                loss.append(weight * criterion_loss(outputs))
            
            # 总损失
            loss = torch.sum(torch.stack(loss))
            losses.append(loss.item())
    
    # 合并所有批次的预测结果
    preds = torch.cat(preds, dim=0).cpu().numpy()
    masks = torch.cat(masks, dim=0).cpu().numpy()
    
    # 确保预测数量与数据集大小一致
    assert preds.shape[0] == len(val_loader.dataset)
    assert masks.shape[0] == len(val_loader.dataset)
    
    # 调整维度 (N x 1 x H x W -> N x H x W)
    preds = np.squeeze(preds, axis=1)
    masks = np.squeeze(masks, axis=1)
    
    # 主进程记录平均损失
    if rank == 0:
        logger.info(" * Loss {:.5f}".format(np.mean(losses)))
    
    # 计算性能指标
    ret_metrics = performances(class_name, preds, masks, config.evaluator.metrics)
    
    # 恢复训练模式
    model.train()
    return ret_metrics

if __name__ == "__main__":
    main()