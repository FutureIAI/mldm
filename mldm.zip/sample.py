import warnings
import argparse
import torch
from easydict import EasyDict
import yaml
import os
import numpy as np
from utils.dist_helper import setup_distributed
from torch.nn.parallel import DistributedDataParallel as DDP
import torch.nn.functional as F
from PIL import Image
from tqdm import tqdm
from samples.spaced_sample import SpacedDiffusionBeatGans
from models.sdas.create_models import create_diffusion_unet,create_classifier_unet
import math
import random
from utils.categories import CategoriesDict



warnings.filterwarnings('ignore')
parser = argparse.ArgumentParser(description="SDAS sampling")
parser.add_argument("--config", default="./experiments/{}/sample.yaml")
parser.add_argument("--dataset", default="MVTec-AD", choices=['MVTec-AD', 'BTAD'])
parser.add_argument("--local_rank", default=-1, type=int)


def update_config(config, world_size):
   
    assert config.dataset.H == config.dataset.W
    config.unet.use_fp16 = False

    config.classifier.image_size = config.dataset.H
    config.unet.image_size = config.dataset.H
    config.iter_number = int(math.ceil(config.sample_number / (world_size * config.dataset.batch_size)))

    return config

def random_between_a_and_b(a, b):
    assert b >= a
    return random.random() * (b - a) + a

def main():
    args = parser.parse_args()

    # 获取当前数据集的类别字典
    args.class_name_dict = CategoriesDict[args.dataset]
    # 根据数据集名称格式化配置文件路径
    args.config = args.config.format(args.dataset)

    # 读取配置文件
    with open(args.config) as f:
        config = EasyDict(yaml.load(f, Loader=yaml.FullLoader))

    # 设置分布式训练环境
    rank, world_size = setup_distributed()

    # 更新配置
    config = update_config(config, world_size)

    # 创建测试采样器
    test_sampler = SpacedDiffusionBeatGans(**config.TestSampler)

    # 创建并初始化扩散模型
    model = create_diffusion_unet(**config.unet).cuda()
    model.eval()

    # 创建并初始化分类器模型
    classifier = create_classifier_unet(**config.classifier).cuda()
    classifier.eval()

    # 获取本地GPU编号
    local_rank = int(os.environ["LOCAL_RANK"])

    # 使用分布式数据并行包装模型
    model = DDP(
        model,
        device_ids=[local_rank],
        output_device=local_rank,
        find_unused_parameters=False,
    )

    # 使用分布式数据并行包装分类器
    classifier = DDP(
        classifier,
        device_ids=[local_rank],
        output_device=local_rank,
        find_unused_parameters=False,
    )

    # 条件函数（引导采样方向）
    def cond_fn(x, t, y=None):
        assert y is not None
        with torch.enable_grad():
            # 准备需要梯度的输入
            x_in = x.detach().requires_grad_(True)
            # 分类器预测
            logits = classifier(x_in, t)
            # 计算log softmax
            log_probs = F.log_softmax(logits, dim=-1)
            # 选择目标类别的概率
            selected = log_probs[range(len(logits)), y.view(-1)]
            # 计算梯度
            guided_grad = torch.autograd.grad(selected.sum(), x_in)[0]
            # 返回缩放后的梯度
            return guided_grad * config.classifier_scale

    # 设置计算设备
    device = torch.device('cuda')
    # 获取批次大小、通道数、图像高度和宽度
    B, C, H, W = config.dataset.batch_size, config.dataset.channels, config.dataset.H, config.dataset.W

    # 遍历所有类别
    for class_name in args.class_name_dict:
        # 获取当前类别的索引
        class_idx = args.class_name_dict[class_name]

        # 创建输出目录
        config.export_path = os.path.join(config.workspace.root, class_name)
        os.makedirs(config.export_path, exist_ok=True)

        # 创建类别标签张量
        y = torch.from_numpy(np.array([class_idx])).repeat(B).to(device)

        # 设置进度条（仅主进程显示）
        if rank == 0:
            iterator = iter(tqdm(range(config.iter_number), desc='sample {}'.format(class_name)))
        else:
            iterator = iter(range(config.iter_number))

        # 禁用梯度计算
        with torch.no_grad():
            # 遍历所有迭代次数
            for i in iterator:
                # 生成随机噪声
                xt = torch.randn((B, C, H, W)).to(device)

                # 随机采样s值（引导强度）
                s = random_between_a_and_b(a=0.1, b=0.2)

                # 使用扩散模型生成样本
                x1 = test_sampler.p_sample_loop(
                    model=model,
                    noise=xt,
                    device=device,
                    cond_fn=cond_fn,  # 引导采样函数
                    model_kwargs={'y': y},  # 类别标签参数
                    s=s,  # 引导强度
                )

                # 将张量转换为图像格式并保存
                # 1. 调整维度顺序 (B, C, H, W) -> (B, H, W, C)
                # 2. 从[-1,1]范围转换到[0,255]范围
                # 3. 转换为无符号8位整数
                x1 = np.clip((x1.cpu().numpy().transpose(0, 2, 3, 1) + 1) * 127.5, 
                              a_min=0, a_max=255).astype(np.uint8)

                # 保存生成的图像
                for idx in range(B):
                    Image.fromarray(x1[idx]).save(
                        os.path.join(config.export_path, "rank{}_{}.jpg".format(rank, i * B + idx)))


if __name__ == "__main__":
    main()