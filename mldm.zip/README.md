
训练:
$ python -m torch.distributed.launch --nproc_per_node=1 train_net.py --dataset MVTec-AD --class_name bottle
生成:
$ python -m torch.distributed.launch --nproc_per_node=1 sample.py --dataset MVTec-AD