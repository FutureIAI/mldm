import warnings
import argparse
import torch
from easydict import EasyDict
import yaml
import os
import logging
import pprint
from utils.misc_helper import set_seed,get_current_time,create_logger,AverageMeter
from datasets.data_builder import build_dataloader
from samples.tsamples import UniformSampler
from samples.spaced_sample import SpacedDiffusionBeatGans
from models.sdas.create_models import create_classifier_unet
from utils.optimizer_helper import get_optimizer
from utils.criterion_helper import build_criterion
from utils.misc_helper import save_checkpoint
from utils.dist_helper import setup_distributed
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from utils.categories import  Categories


warnings.filterwarnings('ignore')
parser = argparse.ArgumentParser(description="train diffusion model guided classifier")
parser.add_argument("--config", default="experiments/{}/classifier.yaml")
parser.add_argument("--dataset", default="MVTec-AD",choices=['MVTec-AD'，'BTAD'])
parser.add_argument("--local_rank", default=-1, type=int)


def compute_top_k(logits, labels, k, reduction="mean"):
    """
    计算 top-k 准确率
    
    参数:
    logits: 模型输出预测概率 [batch_size, num_classes]
    labels: 真实标签 [batch_size]
    k: 计算前k个预测的准确率
    reduction: 计算方式 ('mean' 或 'none')
    
    返回:
    top-k 准确率 (标量或向量)
    """
    # 获取每个样本的前k个预测类别
    _, top_ks = torch.topk(logits, k, dim=-1)
    
    # 检查真实标签是否在前k个预测中
    if reduction == "mean":
        # 返回所有样本的平均值 (标量)
        return (top_ks == labels[:, None]).float().sum(dim=-1).mean().item()
    elif reduction == "none":
        # 返回每个样本的单独结果 [batch_size]
        return (top_ks == labels[:, None]).float().sum(dim=-1)


def update_config(config, args):
    """更新配置参数"""
    # 设置数据集类别列表
    config.dataset.class_name_list = args.class_name_list
    # 设置分类器输入图像尺寸
    config.classifier.image_size = config.dataset.input_size[0]
    return config


def main():
    # 解析命令行参数
    args = parser.parse_args()

    # 根据数据集名称获取类别列表
    args.class_name_list = Categories[args.dataset]
    # 根据数据集名称格式化配置文件路径
    args.config = args.config.format(args.dataset)

    # 加载YAML配置文件
    with open(args.config) as f:
        config = EasyDict(yaml.load(f, Loader=yaml.FullLoader))

    # 设置分布式训练环境
    rank, world_size = setup_distributed()

    # 设置随机种子确保可复现性
    set_seed(config.random_seed)

    # 更新配置信息
    config = update_config(config, args)

    # 设置实验路径和保存目录
    config.exp_path = os.path.dirname(args.config)
    config.checkpoints_path = os.path.join(config.exp_path, config.saver.checkpoints_dir)
    config.log_path = os.path.join(config.exp_path, config.saver.log_dir)

    # 创建数据加载器 (仅使用训练集，验证集设为None)
    train_loader, _ = build_dataloader(config.dataset, distributed=True)

    # 主进程创建必要目录和日志
    if rank == 0:
        os.makedirs(config.checkpoints_path, exist_ok=True)
        os.makedirs(config.log_path, exist_ok=True)

        current_time = get_current_time()
        logger = create_logger(
            "sdas_classifier_logger", config.log_path + "/sdas_classifier_{}.log".format(current_time)
        )

        logger.info("args: {}".format(pprint.pformat(args)))
        logger.info("config: {}".format(pprint.pformat(config)))
        logger.info("train_loader len is {}".format(len(train_loader)))

    # 获取本地GPU编号
    local_rank = int(os.environ["LOCAL_RANK"])

    # 创建扩散采样器
    train_sampler = SpacedDiffusionBeatGans(**config.TrainSampler)
    # 创建均匀时间步采样器
    Tsampler = UniformSampler(train_sampler)

    # 创建分类器模型并转移到GPU
    model = create_classifier_unet(**config.classifier).cuda()
    # 将批归一化层转换为分布式版本
    model = torch.nn.SyncBatchNorm.convert_sync_batchnorm(model)

    # 使用分布式数据并行包装模型
    model = DDP(
        model,
        device_ids=[local_rank],
        output_device=local_rank,
        find_unused_parameters=True,
    )

    # 获取优化器
    optimizer = get_optimizer(model.parameters(), config.trainer.optimizer)

    # 训练循环
    last_epoch = 0
    for epoch in range(last_epoch, config.trainer.max_epoch):
        last_iter = epoch * len(train_loader)
        
        # 设置训练数据加载器采样器的新epoch
        train_loader.sampler.set_epoch(epoch)

        # 训练一个epoch
        top_1_acc = train_one_epoch(
            config,
            train_loader,
            model,
            optimizer,
            Tsampler,
            train_sampler,
            epoch,
            last_iter,
        )

        # 主进程打印并保存检查点
        if rank == 0 and (epoch + 1) % config.trainer.save_freq_epoch == 0:
            logger.info(" * Top 1 acc {:.5f}".format(top_1_acc))
            save_checkpoint(
                {
                    "epoch": epoch + 1,
                    "arch": config,
                    "state_dict": model.state_dict(),
                    "acc": top_1_acc,
                },
                config,
                epoch=epoch + 1
            )


def train_one_epoch(
    config,
    train_loader,
    model,
    optimizer,
    Tsampler,
    sampler,
    epoch,
    start_iter,
):
    """训练一个epoch"""
    # 获取分布式训练信息
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    
    # 获取主进程的日志器
    if rank == 0:
        logger = logging.getLogger("sdas_classifier_logger")

    # 初始化损失记录器
    losses = AverageMeter(config.trainer.print_freq_step)
    # 创建损失函数
    criterion = build_criterion(config.criterion)
    # 设置为训练模式
    model.train()

    # 初始化精度计算容器
    epoch_preds = []
    epoch_labels = []

    # 遍历训练数据
    for i, input in enumerate(train_loader):
        # 计算当前总步数
        curr_step = start_iter + i
        
        # 获取图像数据和类别标签
        imgs, class_labels = input['image'].cuda(), input['class_id'].cuda()

        # 扩散模型训练过程
        x_start = imgs
        # 从均匀分布采样时间步
        t, weight = Tsampler.sample(len(x_start), x_start.device)
        # 从扩散模型采样加噪图像
        x_input = sampler.q_sample(x_start, t)

        # 模型前向传播
        pred = model(x_input, timesteps=t)

        # 计算损失
        loss = []
        for name, criterion_loss in criterion.items():
            weight = criterion_loss.weight
            loss.append(weight * criterion_loss({'pred': pred, 'label': class_labels}))

        # 总损失
        loss = torch.sum(torch.stack(loss))

        # 分布式训练中的损失聚合
        reduced_loss = loss.clone()
        dist.all_reduce(reduced_loss)
        reduced_loss = reduced_loss / world_size

        # 更新损失记录
        losses.update(reduced_loss.item())

        # 保存预测和标签用于后续精度计算
        epoch_preds.append(pred)
        epoch_labels.append(class_labels)

        # 反向传播
        optimizer.zero_grad()
        loss.backward()

        # 梯度裁剪
        if config.trainer.get("clip_max_norm", None):
            max_norm = config.trainer.clip_max_norm
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm)

        # 参数更新
        optimizer.step()

        # 主进程定期打印训练信息
        if rank == 0 and (curr_step % config.trainer.print_freq_step == 0):
            logger.info(
                "Epoch: [{0}/{1}]\t"
                "Iter: [{2}/{3}]\t"
                "Loss {loss.val:.5f} ({loss.avg:.5f})\t"
                .format(
                    epoch + 1,
                    config.trainer.max_epoch,
                    curr_step + 1,
                    len(train_loader) * config.trainer.max_epoch,
                    loss=losses,
                )
            )

    # 聚合所有GPU的预测和标签
    epoch_preds = torch.cat(epoch_preds, dim=0)
    epoch_labels = torch.cat(epoch_labels, dim=0)

    # 分布式聚合所有GPU的预测
    all_preds = [epoch_preds for _ in range(world_size)]
    all_labels = [epoch_labels for _ in range(world_size)]

    dist.all_gather(all_preds, epoch_preds)
    dist.all_gather(all_labels, epoch_labels)

    all_labels = torch.cat(all_labels, dim=0)
    all_preds = torch.cat(all_preds, dim=0)

    # 计算并返回top-1准确率
    return compute_top_k(all_preds, all_labels, 1)
if __name__ == "__main__":
    main()