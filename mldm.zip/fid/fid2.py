# -*- coding: UTF-8 -*-
import time

import torch
import torch.nn as nn
from torchvision import transforms
from torchvision.models import inception_v3
from scipy import linalg
import numpy as np
from PIL import Image
import os
import csv
from tqdm import tqdm

# 配置路径
# base_path1 = r"F:\experiments\1.vae"
base_path1 = r"F:\experiments\BTAD\5"
# base_path1 = r"F:\experiments\3.1DDPM"
# base_path1 = r"F:\experiments\BTAD\processed_BTAD"
# base_path1 = r"F:\成都理工\0-毕业论文\5实验\Mvtec\S0"

base_path2 = r"F:\experiments\BTAD\processed_BTAD"
# base_path2 = r"F:\成都理工\0-毕业论文\5实验\processed_Mvtec"
result_file = "btad_my_fid_results.csv"




class FIDCalculator:
    def __init__(self, device='cuda'):
        print("\n🔥 初始化FID计算器 🔥")
        print("=" * 60)
        print(f" 🖥️  使用设备: {device.upper()}")
        print(f" 📦 PyTorch版本: {torch.__version__}")
        print(f" 🔢 NumPy版本: {np.__version__}")
        print("=" * 60 + "\n")

        self.device = device

        print("🔄 加载Inception-v3模型中...")
        self.model = inception_v3(
            pretrained=True,
            transform_input=True,
            init_weights=False
        )
        self.model.fc = nn.Identity()  # 移除非线性层
        self.model.aux_logits = False
        self.model.eval()
        self.model.to(device)

        print("✅ 模型加载完成！基础配置：")
        print(f" - 输入尺寸: 299x299x3")
        print(f" - 特征维度: 2048")
        print(f" - 设备位置: {'GPU🔥' if device == 'cuda' else 'CPU❄️'}\n")

        # 预处理流水线
        self.preprocess = transforms.Compose([
            transforms.ToTensor(),  # 自动转换到[0,1]
        ])

    def load_images(self, folder):
        print(f"\n📂 开始加载: {folder}")
        try:
            files = [os.path.join(folder, f) for f in os.listdir(folder)
                     if f.lower().endswith(('.png', '.jpg', '.jpeg','bmp'))]
        except FileNotFoundError as e:
            print(f"❌ 路径不存在: {folder}")
            return None

        print(f" 📌 发现 {len(files)} 个图像文件")

        valid_files = 0
        error_files = 0
        dataset = []
        for f in files:
            try:
                img = Image.open(f).convert('RGB')
                tensor = self.preprocess(img)
                dataset.append(tensor)
                valid_files += 1
                if valid_files % 50 == 0:
                    print(f" ▸ 已加载 {valid_files} 张...")
            except Exception as e:
                error_files += 1
                print(f"  ❗ 错误文件: {os.path.basename(f)} - {str(e)}")

        print(f"\n✅ 加载完成：有效 {valid_files} 张 · 错误 {error_files} 张\n")
        return torch.stack(dataset) if dataset else None

    def extract_features(self, images, batch_size=32):
        if images is None or len(images) == 0:
            return None

        total_batches = (len(images) + batch_size - 1) // batch_size
        print(f"🧬 开始特征提取 (批次大小: {batch_size})")
        print(f" 📦 总数据量: {len(images)}")
        print(f" 🚚 总批次: {total_batches}")

        features = []
        for batch_idx in range(0, len(images), batch_size):
            batch_num = (batch_idx // batch_size) + 1
            print(f"\n🔃 处理批次 {batch_num}/{total_batches}")

            batch = images[batch_idx:batch_idx + batch_size].to(self.device)

            print(f" ✨ 输入尺寸: {batch.shape}")
            batch = nn.functional.interpolate(
                batch,
                size=(299, 299),
                mode='bilinear',
                align_corners=False
            )

            # 转换到[-1, 1]
            batch = (batch - 0.5) * 2
            print(f" 🔧 预处理后尺寸: {batch.shape}")

            with torch.no_grad():
                features_batch = self.model(batch)
                print(f" 💡 特征形状: {features_batch.shape}")
                features.append(features_batch.cpu().numpy())

        print("\n🎉 特征提取完成！\n")
        return np.concatenate(features, axis=0)

    def calculate_fid(self, path1, path2):
        print("\n" + "=" * 60)
        print(f"🚀 开始计算 FID: [ {os.path.basename(path1)} ] vs [ {os.path.basename(path2)} ]")
        print("=" * 60)

        # 加载数据
        print("\n🔍 加载数据集1...")
        images1 = self.load_images(path1)
        print("\n🔍 加载数据集2...")
        images2 = self.load_images(path2)

        # 验证数据
        if images1 is None or images2 is None:
            print("\n❎ 数据加载失败，跳过计算")
            return float('nan')

        print(f" 📊 数据集统计:")
        print(f"   → 数据集1样本数: {len(images1)}")
        print(f"   → 数据集2样本数: {len(images2)}\n")

        # 特征提取
        print("\n️ 特征提取阶段")
        features1 = self.extract_features(images1)
        features2 = self.extract_features(images2)

        if features1 is None or features2 is None:
            print("\n❎ 特征提取失败，跳过计算")
            return float('nan')

        # 计算统计量
        print("\n 计算统计量...")
        print(f"   → 正计算均值...")
        mu1, sigma1 = self._calculate_statistics(features1)
        mu2, sigma2 = self._calculate_statistics(features2)

        print(f"   ✔ 完成统计量计算")
        print(f"   → 均值向量维度: {mu1.shape}")
        print(f"   → 协方差矩阵维度: {sigma1.shape}\n")

        # FID计算
        print(" 开始FID计算...")
        fid = self._compute_fid(mu1, sigma1, mu2, sigma2)

        print("\n" + "=" * 50)
        print(f" 最终FID值: {fid:.2f}")
        print("=" * 50 + "\n")
        return fid

    def _calculate_statistics(self, features):
        mu = np.mean(features, axis=0)
        sigma = np.cov(features, rowvar=False)  # 使用特征作为变量(列)
        return mu, sigma

    def _compute_fid(self, mu1, sigma1, mu2, sigma2, eps=1e-6):
        diff = mu1 - mu2

        # 计算协方差矩阵平方根
        cov_sqrt, _ = linalg.sqrtm(sigma1 @ sigma2, disp=False)

        # 处理数值稳定性问题
        if not np.isfinite(cov_sqrt).all():
            print("⚠️ 检测到数值不稳定，添加扰动项")
            offset = np.eye(sigma1.shape[0]) * eps
            cov_sqrt = linalg.sqrtm((sigma1 + offset) @ (sigma2 + offset))

        cov_sqrt = cov_sqrt.real

        # 计算迹差异
        trace_term = np.trace(sigma1 + sigma2 - 2 * cov_sqrt)

        return np.dot(diff, diff) + trace_term


def batch_process():
    print("\n" + "★" * 60)
    print("✨ FID批量计算程序启动 ✨")
    print("★" * 60 + "\n")

    # 设备选择
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    if device == 'cuda':
        print("🎉 检测到CUDA设备，启用GPU加速")
    else:
        print("⚡ 使用CPU进行计算（性能可能受限）")

    # 初始化FID计算器
    calculator = FIDCalculator(device=device)

    # 扫描类别
    print("\n 正在扫描基础路径...")
    categories = [d for d in os.listdir(base_path1)
                  if os.path.isdir(os.path.join(base_path1, d))]
    print(f"发现 {len(categories)} 个类别: {categories}\n")

    # 准备结果文件
    with open(result_file, 'w', newline='', encoding='utf-8-sig') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['类别', 'FID值', '原始样本数', '处理后样本数', '结果状态'])

        # 遍历类别
        for category in tqdm(categories, desc="总体进度"):
            print("\n" + "=" * 50)
            print(f"🔄 正在处理类别: {category}")
            print("=" * 50)

            path1 = os.path.join(base_path1, category)
            path2 = os.path.join(base_path2, category)

            # 路径验证
            if not os.path.exists(path2):
                print(f"❌ 目录不存在: {path2}")
                writer.writerow([category, 'N/A', 'N/A', 'N/A', '目标路径丢失'])
                continue

            # 样本计数
            n1 = len([f for f in os.listdir(path1)
                      if f.lower().endswith(('.png', '.jpg', '.jpeg'))])
            n2 = len([f for f in os.listdir(path2)
                      if f.lower().endswith(('.png', '.jpg', '.jpeg'))])

            # 执行计算
            try:
                fid = calculator.calculate_fid(path1, path2)
                status = '成功 ✅' if not np.isnan(fid) else '失败 ❌'
                writer.writerow([category, f"{fid:.2f}", n1, n2, status])
            except Exception as e:
                print(f"\n❌ 计算错误: {str(e)}")
                writer.writerow([category, 'N/A', n1, n2, f'错误: {type(e).__name__}'])

    print("\n" + "★" * 60)
    print(f"🎉 所有计算完成！结果已保存至: {result_file}")
    print("★" * 60 + "\n")


if __name__ == '__main__':
    # 启动主程序

    start_time = time.perf_counter()  # 记录开始时间
    batch_process()
    end_time = time.perf_counter()  # 记录结束时间
    elapsed_time = end_time - start_time
    print(f"程序耗时: {elapsed_time:.3f} 秒")