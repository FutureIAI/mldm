# -*- coding: UTF-8 -*-
import matplotlib.pyplot as plt
import numpy as np
# 设置中文字体，解决中文显示问题
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 使用微软雅黑字体
matplotlib.rcParams['axes.unicode_minus'] = False  # 正常显示负号
# 数据
learning_rates = ['1e-4', '1e-5']  # 学习率
batch_size_16_is = [4.11, 3.85]   # 批量大小为16时的IS值
batch_size_32_is = [4.25, 3.96]   # 批量大小为32时的IS值

# 设置图形大小
plt.figure(figsize=(8, 6))

# 绘制两条折线
plt.plot(learning_rates, batch_size_16_is, label='批量大小 = 16', marker='o', color='b')
plt.plot(learning_rates, batch_size_32_is, label='批量大小 = 32', marker='o', color='r')

# 添加标题和标签
plt.title('学习率 vs IS值（不同批量大小）')
plt.xlabel('学习率 (lr)')
plt.ylabel('IS值')
plt.legend()

# 显示图形
plt.grid(True)
plt.tight_layout()
plt.show()

