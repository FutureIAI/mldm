import numpy as np
import cv2
import lpips
import torch
from skimage.metrics import structural_similarity as ssim
from torchvision import transforms
from PIL import Image
import os


# ================== 1. 安全读取中文路径图像 ==================
def safe_imread(path):
    """解决中文路径读取问题 (参考网页1[1,2,3,5](@ref))"""
    try:
        # 二进制读取后解码
        raw_data = np.fromfile(path, dtype=np.uint8)
        img = cv2.imdecode(raw_data, cv2.IMREAD_COLOR)
        if img is None:
            raise ValueError(f"图像解码失败: {path}")
        return img
    except Exception as e:
        raise RuntimeError(f"读取图像错误: {str(e)}") from e


# ================== 2. 图像质量评估函数 ==================
def calculate_psnr(img1, img2):
    """计算PSNR (参考网页6[6,9,10](@ref))"""
    img1 = np.array(img1, dtype=np.float32)
    img2 = np.array(img2, dtype=np.float32)

    mse = np.mean((img1 - img2)  ** 2)
    if mse == 0:
        return float('inf')

    max_pixel = 255.0
    return 20 * np.log10(max_pixel / np.sqrt(mse))


def calculate_ssim(img1, img2):
    """计算SSIM (改进版，支持彩色图像) (参考网页6[6,9,11](@ref))"""
    if img1.shape != img2.shape:
        raise ValueError("图像尺寸不一致")

    # 多通道SSIM计算 (通道数自动检测)
    return ssim(img1, img2, channel_axis=2, data_range=255)


class LPIPSCalculator:
    """LPIPS计算器 (封装预处理逻辑) (参考网页6[6,8,9](@ref))"""

    def __init__(self, net='alex'):
        self.model = lpips.LPIPS(net=net, verbose=False)
        self.transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
        ])

    def __call__(self, img1_path, img2_path):
        # 统一使用PIL读取保证通道顺序
        img1 = self.load_image(img1_path)
        img2 = self.load_image(img2_path)

        img1_tensor = self.transform(img1).unsqueeze(0)
        img2_tensor = self.transform(img2).unsqueeze(0)

        return self.model(img1_tensor, img2_tensor).item()

    def load_image(self, path):
        """支持中文路径的PIL读取 (参考网页3[3,5](@ref))"""
        try:
            with open(path, 'rb') as f:
                return Image.open(f).convert('RGB')
        except Exception as e:
            raise RuntimeError(f"LPIPS图像读取失败: {path}") from e


# ================== 3. 主程序逻辑 ==================
if __name__ == "__main__":
    # 配置路径 (原始路径保持中文)
    img1_path = r'F:\成都理工\0-毕业论文\5实验\test.jpg'
    img2_path = r'F:\成都理工\0-毕业论文\5实验\processed_Mvtec\bottle\000.png'

    try:
        # 读取并验证图像
        img1 = safe_imread(img1_path)
        img2 = safe_imread(img2_path)

        if img1 is None or img2 is None:
            raise ValueError("图像数据为空，请检查文件路径")

        # 计算PSNR
        psnr_value = calculate_psnr(img1, img2)
        print(f"PSNR: {psnr_value:.2f} dB")

        # 计算SSIM (改进版)
        ssim_value = calculate_ssim(img1, img2)
        print(f"SSIM: {ssim_value:.4f}")

        # 计算LPIPS
        lpips_calculator = LPIPSCalculator(net='alex')
        lpips_value = lpips_calculator(img1_path, img2_path)
        print(f"LPIPS: {lpips_value:.4f}")

    except Exception as e:
        print(f"错误发生: {str(e)}")
        # 显示具体路径问题
        if not os.path.exists(img1_path):
            print(f"文件不存在: {img1_path}")
        if not os.path.exists(img2_path):
            print(f"文件不存在: {img2_path}")