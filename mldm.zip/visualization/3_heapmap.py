
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np
import cv2
from torchvision import transforms


# -------------------- 1. 模型定义（假设的MSA模块和UNet结构） --------------------
class MultiScaleAttention(nn.Module):
    """多尺度注意力模块（示例结构）"""

    def __init__(self, in_channels, reduction=8):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, in_channels // reduction, kernel_size=3, padding=1, dilation=1)
        self.conv2 = nn.Conv2d(in_channels, in_channels // reduction, kernel_size=5, padding=2, dilation=2)
        self.conv3 = nn.Conv2d(in_channels, in_channels // reduction, kernel_size=7, padding=3, dilation=4)
        self.attn = nn.Sequential(
            nn.Conv2d(in_channels // reduction * 3, 1, kernel_size=1),
            nn.Sigmoid()
        )

    def forward(self, x):
        x1 = self.conv1(x)
        x2 = self.conv2(x)
        x3 = self.conv3(x)
        x_cat = torch.cat([x1, x2, x3], dim=1)
        attn_map = self.attn(x_cat)
        return x * attn_map


class SimpleUNetWithMSA(nn.Module):
    """示例UNet结构（包含MSA模块）"""

    def __init__(self):
        super().__init__()
        # 编码器部分（示例）
        self.encoder = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            MultiScaleAttention(128),  # MSA模块位于第3层
            nn.MaxPool2d(2)
        )
        # 解码器部分（示例）
        self.decoder = nn.Sequential(
            nn.ConvTranspose2d(128, 64, kernel_size=2, stride=2),
            nn.ReLU(),
            nn.Conv2d(64, 3, kernel_size=3, padding=1),
            nn.Sigmoid()
        )

    def forward(self, x):
        x = self.encoder(x)
        x = self.decoder(x)
        return x


# -------------------- 2. 模型加载与梯度捕获 --------------------
class GradCAMWrapper(nn.Module):
    """包装模型以捕获目标层（MSA模块）的梯度和激活"""

    def __init__(self, model, target_layer):
        super().__init__()
        self.model = model
        self.target_layer = target_layer
        self.activations = []
        self.gradients = []

        # 注册前向和反向钩子
        self.target_layer.register_forward_hook(self.save_activation)
        self.target_layer.register_backward_hook(self.save_gradient)

    def save_activation(self, module, input, output):
        self.activations.append(output.detach())

    def save_gradient(self, module, grad_input, grad_output):
        self.gradients.append(grad_output[0].detach())

    def forward(self, x):
        return self.model(x)





# 加载模型（假设已训练好）
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# model = SimpleUNetWithMSA().to(device)
# model.load_state_dict(torch.load('F:\CODE\\realNet\RealNet-main\RealNet-main\pretrain\\256x256_diffusion.pt'))  # 替换为你的模型路径
# model.eval()
from diffusers import UNet2DModel

# 使用Hugging Face Diffusers库的标准扩散模型
model = UNet2DModel(
    sample_size=256,
    in_channels=3,
    out_channels=3,
    layers_per_block=2,
    block_out_channels=(128, 256, 512, 1024),
    norm_num_groups=32,
    time_embedding_type="positional",  # 包含time_embed层
).to(device)
model.load_state_dict(torch.load('F:\CODE\\realNet\RealNet-main\RealNet-main\pretrain\\256x256_diffusion.pt'))













# 指定目标层（这里假设是编码器的第3层）
target_layer = model.encoder[4]  # 对应MultiScaleAttention模块
wrapped_model = GradCAMWrapper(model, target_layer)

# -------------------- 3. 数据预处理 --------------------
img_path = "F:\成都理工\\0-毕业论文\\5实验\\test.jpg"
img = Image.open(img_path).convert("RGB")

preprocess = transforms.Compose([
    transforms.Resize((512, 512)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]),
])
input_tensor = preprocess(img).unsqueeze(0).to(device)  # [1, 3, 512, 512]


# -------------------- 4. 生成Grad-CAM热力图 --------------------
def generate_gradcam(model, input_tensor):
    # 前向传播
    output = model(input_tensor)

    # 假设目标类别为生成图像的重建误差（示例，需根据任务调整）
    loss = torch.mean((output - input_tensor)  ** 2)

    # 反向传播
    model.zero_grad()
    loss.backward()

    # 获取激活和梯度
    activations = model.activations[0]
    gradients = model.gradients[0]

    # 计算权重（全局平均池化梯度）
    weights = torch.mean(gradients, dim=(2, 3), keepdim=True)

    # 加权激活图
    gradcam = torch.sum(activations * weights, dim=1, keepdim=True)
    gradcam = F.relu(gradcam)

    # 上采样到输入尺寸
    gradcam = F.interpolate(gradcam, size=(512, 512), mode='bilinear', align_corners=False)
    gradcam = gradcam.squeeze().cpu().numpy()
    return gradcam


# 生成热力图
with torch.no_grad():
    gradcam = generate_gradcam(wrapped_model, input_tensor)


# -------------------- 5. 可视化热力图 --------------------
def overlay_heatmap(img, heatmap, alpha=0.5):
    # 转换为OpenCV格式
    img = np.array(img)
    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

    # 归一化热力图并应用颜色映射
    heatmap = (heatmap - heatmap.min()) / (heatmap.max() - heatmap.min())
    heatmap = np.uint8(255 * heatmap)
    heatmap_colored = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)

    # 叠加到原图
    superimposed = cv2.addWeighted(img, alpha, heatmap_colored, 1 - alpha, 0)
    return cv2.cvtColor(superimposed, cv2.COLOR_BGR2RGB)


# 原始图像反归一化
def denormalize(tensor):
    mean = torch.tensor([0.5, 0.5, 0.5]).view(1, 3, 1, 1).to(device)
    std = torch.tensor([0.5, 0.5, 0.5]).view(1, 3, 1, 1).to(device)
    return tensor * std + mean


original_img = denormalize(input_tensor).squeeze().permute(1, 2, 0).cpu().numpy()
original_img = np.clip(original_img, 0, 1)  # 确保像素值在[0,1]

# 生成叠加热力图的图像
superimposed_img = overlay_heatmap(Image.fromarray((original_img * 255).astype(np.uint8)), gradcam)

# 可视化
plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
plt.imshow(original_img)
plt.title("Original Image")
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(superimposed_img)
plt.title("Grad-CAM Heatmap (MSA Layer)")
plt.axis('off')

plt.show()