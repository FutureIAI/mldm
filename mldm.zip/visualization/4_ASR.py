import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager

# Define Chinese font for Matplotlib
font = font_manager.FontProperties(fname='C:/Windows/Fonts/simhei.ttf')  # Path to SimHei font

# Data for each method (FGSM, PGD, C&W, MLDAG)
categories = ['Bottle', 'Cable', 'Capsule', 'Carpet', 'Grid', 'Hazelnut', 'Leather', 'Metal Nut', 'Pill', 'Screw',
              'Tile', 'Toothbrush', 'Transistor', 'Wood', 'Zipper']

# Attack success rates for ResNet-18 and YOLOv11
fgsm_resnet = [50, 53, 48, 58, 45, 53, 55, 50, 60, 52, 55, 54, 58, 56, 60]
fgsm_yolo = [35, 38, 33, 48, 30, 36, 39, 35, 44, 37, 41, 38, 46, 40, 44]

pgd_resnet = [62, 65, 60, 68, 55, 64, 66, 61, 72, 63, 67, 66, 70, 68, 71]
pgd_yolo = [47, 50, 46, 55, 43, 50, 51, 46, 58, 49, 52, 49, 55, 51, 55]

c_and_w_resnet = [65, 67, 63, 70, 58, 66, 69, 63, 74, 66, 70, 68, 72, 71, 73]
c_and_w_yolo = [42, 44, 40, 50, 38, 43, 45, 41, 52, 43, 46, 43, 49, 45, 49]

mldag_resnet = [72, 74, 70, 78, 66, 73, 75, 71, 80, 73, 77, 76, 79, 78, 80]
mldag_yolo = [55, 57, 53, 62, 47, 54, 56, 53, 64, 55, 58, 55, 60, 56, 59]

# Create a bar chart
fig, ax = plt.subplots(figsize=(14, 8))

bar_width = 0.2
index = np.arange(len(categories))

# Set positions for each set of bars
bar1_resnet = ax.bar(index - 1.5 * bar_width, fgsm_resnet, bar_width, label='FGSM (ResNet-18)', color='blue')
bar1_yolo = ax.bar(index - 0.5 * bar_width, fgsm_yolo, bar_width, label='FGSM (YOLOv11)', color='lightblue')

bar2_resnet = ax.bar(index + 0.5 * bar_width, pgd_resnet, bar_width, label='PGD (ResNet-18)', color='green')
bar2_yolo = ax.bar(index + 1.5 * bar_width, pgd_yolo, bar_width, label='PGD (YOLOv11)', color='lightgreen')

bar3_resnet = ax.bar(index - 1.5 * bar_width, c_and_w_resnet, bar_width, label='C&W (ResNet-18)', color='red')
bar3_yolo = ax.bar(index - 0.5 * bar_width, c_and_w_yolo, bar_width, label='C&W (YOLOv11)', color='lightcoral')

bar4_resnet = ax.bar(index + 0.5 * bar_width, mldag_resnet, bar_width, label='MLDAG (ResNet-18)', color='purple')
bar4_yolo = ax.bar(index + 1.5 * bar_width, mldag_yolo, bar_width, label='MLDAG (YOLOv11)', color='plum')

# Labels and title with Chinese text
ax.set_xlabel('类别', fontproperties=font)  # X-axis label in Chinese
ax.set_ylabel('攻击成功率 (%)', fontproperties=font)  # Y-axis label in Chinese
ax.set_title('不同方法的攻击成功率比较', fontproperties=font)  # Title in Chinese
ax.set_xticks(index)
ax.set_xticklabels(categories, rotation=45, ha="right", fontproperties=font)
ax.legend()

# Show the plot
plt.tight_layout()
plt.show()
