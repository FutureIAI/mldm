import matplotlib.pyplot as plt
import matplotlib
import numpy as np

# 设置中文字体，解决中文显示问题
matplotlib.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 使用微软雅黑字体
matplotlib.rcParams['axes.unicode_minus'] = False  # 正常显示负号

# 数据
learning_rates = ['1e-4', '1e-5']  # 学习率
batch_size_16_fid = [131.05, 133.73]   # 批量大小为16时的FID值
batch_size_32_fid = [129.53, 132.29]   # 批量大小为32时的FID值

# 设置图形大小
plt.figure(figsize=(8, 6))

# 绘制两条折线
plt.plot(learning_rates, batch_size_16_fid, label='批量大小 = 16', marker='o', color='b')
plt.plot(learning_rates, batch_size_32_fid, label='批量大小 = 32', marker='o', color='r')

# 添加标题和标签
plt.title('学习率 vs FID值（不同批量大小）')
plt.xlabel('学习率 (lr)')
plt.ylabel('FID值')
plt.legend()

# 显示图形
plt.grid(True)
plt.tight_layout()
plt.show()
