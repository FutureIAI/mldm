import matplotlib.pyplot as plt
import numpy as np

# 配置中文字体（如果不需要中文可删除）
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 通用配置
categories = ['Bottle', 'Cable', 'Capsule', 'Carpet', 'Grid', 'Hazelnut', 'Leather',
             'Mental Nut', 'Pill', 'Screw', 'Tile', 'Toothbrush', 'Transistor', 'Wood', 'Zipper', '平均']
models = ['VAE', 'StyleGAN', 'DDPM', 'LDM', 'MAS-LDM']
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']
width = 0.15
x = np.arange(len(categories))

# FID数据 (越低越好)
fid_data = {
    'VAE': [230.33,323.43,201.65,246.41,242.29,169.00,122.88,228.34,158.64,226.47,260.17,163.70,295.68,180.00,165.42,214.29],
    'StyleGAN': [219.01,307.27,168.00,140.59,251.04,171.24,226.10,223.09,139.03,103.77,252.81,186.41,286.31,208.34,138.39,201.43],
    'DDPM': [201.88,302.71,160.35,144.77,266.99,163.56,222.11,233.62,182.04,110.24,242.82,192.37,280.05,193.78,226.02,208.22],
    'LDM': [163.33,123.43,92.65,46.41,242.29,69.00,122.88,128.34,158.64,90.47,130.17,88.70,126.68,100.10,95.42,118.57],
    'MAS-LDM': [122.45,116.18,73.28,43.67,219.58,73.67,111.57,136.69,91.43,33.40,107.33,79.02,126.24,98.97,91.31,101.65]
}

# 绘制FID图表
plt.figure(figsize=(18, 10))
for i, (model, values) in enumerate(fid_data.items()):
    plt.bar(x + i*width, values, width, label=model, color=colors[i])

plt.title('不同生成模型FID指标对比（越低越好）', fontsize=14, pad=20)
plt.ylabel('FID值', fontsize=12)
plt.xticks(x + width*2, categories, rotation=45, ha='right')
plt.legend(loc='upper left', bbox_to_anchor=(1, 1))
plt.grid(True, axis='y', linestyle='--', alpha=0.7)
plt.subplots_adjust(bottom=0.25)  # 增加底部边距
plt.show()

# IS数据 (越高越好)
is_data = {
    'VAE': [1.33,1.43,1.65,1.41,1.29,2.00,1.28,1.34,1.64,1.47,1.17,1.70,1.68,1.09,1.42,1.48],
    'StyleGAN': [1.85,2.23,1.81,1.95,1.88,2.37,1.50,2.49,1.83,1.65,1.55,1.63,1.98,2.06,2.09,1.92],
    'DDPM': [1.87,2.06,1.72,1.90,1.95,2.31,1.54,2.47,1.88,1.65,1.47,1.75,1.90,2.08,1.16,1.84],
    'LDM': [1.89,1.93,1.83,2.02,2.27,1.99,1.58,2.40,1.98,1.68,1.52,1.74,1.92,1.89,1.57,1.88],
    'MAS-LDM': [2.10,2.24,1.99,2.11,2.50,2.22,1.62,2.69,1.91,1.78,1.58,1.88,2.16,2.36,2.20,2.10]
}

# 绘制IS图表
plt.figure(figsize=(18, 10))
for i, (model, values) in enumerate(is_data.items()):
    plt.bar(x + i*width, values, width, label=model, color=colors[i])

plt.title('不同生成模型IS指标对比（越高越好）', fontsize=14, pad=20)
plt.ylabel('IS值', fontsize=12)
plt.xticks(x + width*2, categories, rotation=45, ha='right')
plt.legend(loc='upper left', bbox_to_anchor=(1, 1))
plt.grid(True, axis='y', linestyle='--', alpha=0.7)
plt.subplots_adjust(bottom=0.25)  # 增加底部边距
plt.show()