import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager

# Define Chinese font for Matplotlib
font = font_manager.FontProperties(fname='C:/Windows/Fonts/simhei.ttf')  # Path to SimHei font

# Data for each method (FGSM, PGD, C&W, MLDAG) in (PSNR, SSIM, LPIPS)
categories = ['Bottle', 'Cable', 'Capsule', 'Carpet', 'Grid', 'Hazelnut', 'Leather', 'Metal Nut', 'Pill', 'Screw',
              'Tile', 'Toothbrush', 'Transistor', 'Wood', 'Zipper']

fgsm_psnr = [28.2, 28.7, 28.1, 29.0, 27.8, 28.6, 28.5, 28.0, 29.2, 28.4, 29.0, 28.6, 29.3, 28.8, 29.5]
fgsm_ssim = [0.889, 0.892, 0.888, 0.891, 0.886, 0.889, 0.887, 0.885, 0.894, 0.886, 0.893, 0.888, 0.894, 0.889, 0.897]
fgsm_lpips = [0.170, 0.165, 0.172, 0.158, 0.174, 0.167, 0.169, 0.173, 0.160, 0.172, 0.163, 0.171, 0.159, 0.168, 0.157]

pgd_psnr = [31.8, 32.2, 31.9, 32.4, 32.0, 32.6, 32.3, 31.8, 33.1, 32.0, 32.3, 32.2, 32.7, 32.5, 33.0]
pgd_ssim = [0.913, 0.914, 0.912, 0.915, 0.910, 0.913, 0.911, 0.909, 0.916, 0.910, 0.915, 0.912, 0.916, 0.912, 0.919]
pgd_lpips = [0.132, 0.128, 0.136, 0.120, 0.139, 0.131, 0.134, 0.138, 0.123, 0.133, 0.126, 0.137, 0.121, 0.132, 0.119]

c_and_w_psnr = [34.4, 34.8, 34.6, 35.0, 34.5, 35.1, 34.7, 34.3, 35.5, 34.4, 35.1, 34.7, 35.3, 36.8, 37.6]
c_and_w_ssim = [0.937, 0.938, 0.936, 0.939, 0.934, 0.937, 0.935, 0.933, 0.941, 0.934, 0.939, 0.936, 0.940, 0.936, 0.943]
c_and_w_lpips = [0.101, 0.098, 0.103, 0.091, 0.107, 0.100, 0.104, 0.106, 0.094, 0.102, 0.096, 0.104, 0.093, 0.101, 0.090]

mldag_psnr = [36.5, 36.7, 36.4, 37.1, 36.3, 36.9, 36.6, 36.2, 37.3, 36.5, 37.2, 36.8, 37.4, 36.8, 37.6]
mldag_ssim = [0.950, 0.952, 0.948, 0.954, 0.946, 0.951, 0.947, 0.946, 0.946, 0.953, 0.947, 0.950, 0.948, 0.953, 0.948]
mldag_lpips = [0.077, 0.074, 0.080, 0.072, 0.079, 0.076, 0.078, 0.080, 0.070, 0.078, 0.074, 0.079, 0.072, 0.076, 0.070]

# Create a bar chart
fig, ax = plt.subplots(figsize=(14, 8))

bar_width = 0.2
index = np.arange(len(categories))

# Set positions for each set of bars
bar1_psnr = ax.bar(index - 1.5 * bar_width, fgsm_psnr, bar_width, label='FGSM PSNR', color='blue')
bar2_psnr = ax.bar(index - 0.5 * bar_width, pgd_psnr, bar_width, label='PGD PSNR', color='green')
bar3_psnr = ax.bar(index + 0.5 * bar_width, c_and_w_psnr, bar_width, label='C&W PSNR', color='red')
bar4_psnr = ax.bar(index + 1.5 * bar_width, mldag_psnr, bar_width, label='MLDAG PSNR', color='purple')

bar1_ssim = ax.bar(index - 1.5 * bar_width, fgsm_ssim, bar_width, label='FGSM SSIM', color='lightblue', alpha=0.6)
bar2_ssim = ax.bar(index - 0.5 * bar_width, pgd_ssim, bar_width, label='PGD SSIM', color='lightgreen', alpha=0.6)
bar3_ssim = ax.bar(index + 0.5 * bar_width, c_and_w_ssim, bar_width, label='C&W SSIM', color='lightcoral', alpha=0.6)
bar4_ssim = ax.bar(index + 1.5 * bar_width, mldag_ssim, bar_width, label='MLDAG SSIM', color='plum', alpha=0.6)

bar1_lpips = ax.bar(index - 1.5 * bar_width, fgsm_lpips, bar_width, label='FGSM LPIPS', color='skyblue', alpha=0.3)
bar2_lpips = ax.bar(index - 0.5 * bar_width, pgd_lpips, bar_width, label='PGD LPIPS', color='lightgreen', alpha=0.3)
bar3_lpips = ax.bar(index + 0.5 * bar_width, c_and_w_lpips, bar_width, label='C&W LPIPS', color='salmon', alpha=0.3)
bar4_lpips = ax.bar(index + 1.5 * bar_width, mldag_lpips, bar_width, label='MLDAG LPIPS', color='orchid', alpha=0.3)

# Labels and title with Chinese text
ax.set_xlabel('类别', fontproperties=font)  # X-axis label in Chinese
ax.set_ylabel('评价指标值', fontproperties=font)  # Y-axis label in Chinese
ax.set_title('不同方法的PSNR, SSIM, LPIPS 对比', fontproperties=font)  # Title in Chinese
ax.set_xticks(index)
ax.set_xticklabels(categories, rotation=45, ha="right", fontproperties=font)

# Adjust the legend position to avoid overlap
ax.legend(loc='upper left', bbox_to_anchor=(1, 1))

# Show the plot
plt.tight_layout()
plt.show()
