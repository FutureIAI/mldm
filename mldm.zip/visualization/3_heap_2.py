import torch
import torch.nn as nn
import torchvision
import matplotlib.pyplot as plt
from diffusers import UNet2DModel, DDPMScheduler
from torch.utils.data import DataLoader
from torchvision import transforms
from torchvision.datasets import MNIST
from torchvision.utils import save_image
from tqdm import tqdm

# ================== 1. 数据准备 ==================
import datasets

transform = transforms.Compose([
    transforms.Resize(32),
    transforms.ToTensor(),
    transforms.Normalize([0.5], [0.5])
])

# 定义数据集路径
data_root = "./data"

# 自动下载并加载数据集
dataset = datasets.MNIST(
    root=data_root,
    train=False,        # 加载测试集（如果要训练集则改为 train=True）
    download=True,       # 若数据不存在则自动下载
    transform=transform
)

# 创建数据加载器
dataloader = torch.utils.data.DataLoader(
    dataset,
    batch_size=128,
    shuffle=True
)


# ================== 2. 自编码器定义 ==================
class VAE(nn.Module):
    def __init__(self, latent_dim=4):
        super().__init__()
        # 编码器
        self.encoder = nn.Sequential(
            nn.Conv2d(1, 16, 3, stride=2, padding=1),  # 16x16
            nn.ReLU(),
            nn.Conv2d(16, 32, 3, stride=2, padding=1),  # 8x8
            nn.ReLU(),
            nn.Flatten(),
            nn.Linear(32 * 8 * 8, 256),
            nn.ReLU(),
            nn.Linear(256, 2 * latent_dim)
        )

        # 解码器
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 32 * 8 * 8),
            nn.Unflatten(1, (32, 8, 8)),
            nn.ConvTranspose2d(32, 16, 4, stride=2, padding=1),  # 16x16
            nn.ReLU(),
            nn.ConvTranspose2d(16, 1, 4, stride=2, padding=1),  # 32x32
            nn.Tanh()
        )

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x):
        encoded = self.encoder(x)
        mu, logvar = torch.chunk(encoded, 2, dim=1)
        z = self.reparameterize(mu, logvar)
        return self.decoder(z), mu, logvar


# ================== 3. 自编码器训练 ==================
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
vae = VAE().to(device)
optimizer = torch.optim.Adam(vae.parameters(), lr=1e-3)


# KL散度权重调度
def beta_scheduler(epoch, max_epochs=50):
    return min(epoch / max_epochs, 1.0)


for epoch in range(50):
    for imgs, _ in tqdm(dataloader):
        imgs = imgs.to(device)

        # 前向传播
        recon, mu, logvar = vae(imgs)

        # 损失计算
        recon_loss = nn.MSELoss()(recon, imgs)
        kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
        beta = beta_scheduler(epoch)
        loss = recon_loss + beta * kl_loss

        # 反向传播
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    print(f"Epoch {epoch} | Loss: {loss.item():.4f}")

# ================== 4. 扩散模型定义 ==================
unet = UNet2DModel(
    sample_size=8,  # 潜在空间大小
    in_channels=4,  # 输入通道
    out_channels=4,  # 输出通道
    layers_per_block=2,
    block_out_channels=(64, 128, 256),
    norm_num_groups=8,
).to(device)

noise_scheduler = DDPMScheduler(
    num_train_timesteps=1000,
    beta_start=0.0001,
    beta_end=0.02,
    beta_schedule="linear"
)

# ================== 5. 扩散模型训练 ==================
diff_optimizer = torch.optim.Adam(unet.parameters(), lr=1e-4)

for epoch in range(100):
    for imgs, _ in tqdm(dataloader):
        imgs = imgs.to(device)

        # 编码到潜在空间
        with torch.no_grad():
            latents = vae.encoder(imgs)
            latents = latents[:, :4]  # 取前4维作为潜在表示

        # 添加噪声
        noise = torch.randn_like(latents)
        timesteps = torch.randint(0, 1000, (imgs.shape[0],)).long().to(device)
        noisy_latents = noise_scheduler.add_noise(latents, noise, timesteps)

        # 预测噪声
        noise_pred = unet(noisy_latents, timesteps).sample
        loss = nn.MSELoss()(noise_pred, noise)

        # 优化
        diff_optimizer.zero_grad()
        loss.backward()
        diff_optimizer.step()

    print(f"Diff Epoch {epoch} | Loss: {loss.item():.4f}")


# ================== 6. 热力图生成 ==================
class GradCAM:
    def __init__(self, model, target_layer):
        self.model = model
        self.gradients = None
        self.activations = None

        target_layer.register_forward_hook(self.save_activations)
        target_layer.register_full_backward_hook(self.save_gradients)

    def save_activations(self, module, input, output):
        self.activations = output.detach()

    def save_gradients(self, module, grad_input, grad_output):
        self.gradients = grad_output[0].detach()

    def __call__(self, x):
        # 前向传播
        output = self.model(x)

        # 反向传播
        self.model.zero_grad()
        pred = output.mean()  # 选择目标类别
        pred.backward(retain_graph=True)

        # 计算权重
        weights = torch.mean(self.gradients, dim=(2, 3), keepdim=True)
        cam = torch.sum(weights * self.activations, dim=1, keepdim=True)
        cam = torch.relu(cam)

        # 归一化
        cam -= cam.min()
        cam /= cam.max()
        return cam.squeeze()


# 选择UNet的中间层
target_layer = unet.mid_block.resnets[-1].conv2
grad_cam = GradCAM(unet, target_layer)


# ================== 7. 可视化 ==================
def visualize_sample(sample_idx=0):
    # 获取样本
    img, label = dataset[sample_idx]
    img = img.unsqueeze(0).to(device)

    # 编码到潜在空间
    with torch.no_grad():
        latent = vae.encoder(img)[:, :4]

    # 生成过程
    unet.eval()
    latents = torch.randn_like(latent)
    for t in noise_scheduler.timesteps:
        with torch.no_grad():
            noise_pred = unet(latents, t).sample
        latents = noise_scheduler.step(noise_pred, t, latents).prev_sample

    # 解码生成图像
    with torch.no_grad():
        generated = vae.decoder(latents)

    # 生成热力图
    heatmap = grad_cam(latents)

    # 可视化
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))

    # 原始图像
    axes[0].imshow(img[0, 0].cpu().numpy(), cmap='gray')
    axes[0].set_title(f"Original (Label: {label})")

    # 生成图像
    axes[1].imshow(generated[0, 0].cpu().numpy(), cmap='gray')
    axes[1].set_title("Generated")

    # 热力图
    axes[2].imshow(heatmap.cpu().numpy(), cmap='jet')
    axes[2].set_title("Diffusion Heatmap")

    plt.show()


visualize_sample(sample_idx=5)