import matplotlib.pyplot as plt

# ------- 全局字体 & 负号设置 -------
plt.rcParams['font.sans-serif'] = ['SimHei']      # 使用黑体显示中文
plt.rcParams['axes.unicode_minus'] = False        # 正常显示负号

# ------- 数据 -------
lr_vals   = [1e-4, 1e-5]
fid_bs16  = [131.05, 133.73]
fid_bs32  = [129.53, 132.29]
is_bs16   = [4.11,   3.85]
is_bs32   = [4.25,   3.96]

# ------- 绘图 -------
fig, ax_fid = plt.subplots(figsize=(8,4))
ax_is = ax_fid.twinx()

# FID —— 实线
ax_fid.plot(lr_vals, fid_bs16, label='FID  (batch=16)', marker='o', linestyle='-')
ax_fid.plot(lr_vals, fid_bs32, label='FID  (batch=32)', marker='s', linestyle='-')

# IS —— 虚线
ax_is.plot(lr_vals, is_bs16, label='IS   (batch=16)', marker='o', linestyle='--')
ax_is.plot(lr_vals, is_bs32, label='IS   (batch=32)', marker='s', linestyle='--')

# 轴与标题
ax_fid.set_xlabel('Learning rate')
ax_fid.set_ylabel('FID',  color='tab:blue')
ax_is.set_ylabel('IS',    color='tab:orange')
ax_fid.set_xticks(lr_vals)
ax_fid.set_xticklabels([f'{v:.0e}' for v in lr_vals])

# 中文图名
fig.suptitle('不同学习率和批量大小的FID和IS对比', fontsize=12)

# 图例放在左上角、略微移出绘图区，避免遮挡曲线
lines, labels = ax_fid.get_legend_handles_labels()
lines2, labels2 = ax_is.get_legend_handles_labels()
ax_fid.legend(lines + lines2,
              labels + labels2,
              loc='upper left',
              bbox_to_anchor=(1.25, 1.05),   # 向左、向上各偏移一些
              borderaxespad=0)

# 美化
ax_fid.grid(alpha=0.3, linestyle=':')
fig.tight_layout(rect=[0.08, 0, 1, 0.95])  # 为左侧图例和上方标题预留空间
plt.show()
