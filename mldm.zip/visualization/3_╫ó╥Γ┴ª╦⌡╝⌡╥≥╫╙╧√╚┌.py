import matplotlib.pyplot as plt
import numpy as np

# 配置标签与数据
config_labels = [
    "(8,8)-(8,8)",
    "(8,4)-(4,8)",
    "(4,4)-(4,4)",
    "(4,2)-(2,4)",
    "(2,2)-(2,2)"
]

fid_values = [126.32, 124.17, 122.45, 123.75, 125.89]
is_values = [2.02, 2.21, 2.31, 2.18, 2.09]
x = np.arange(len(config_labels))  # x轴刻度

# 创建画布与双坐标轴
fig, ax1 = plt.subplots(figsize=(10,6))
ax2 = ax1.twinx()

# 绘制FID折线（左轴）
fid_line = ax1.plot(x, fid_values, 's-', color='#1f77b4', 
                   linewidth=2, markersize=8, label='FID')
ax1.set_ylabel('FID (Lower Better)', fontsize=12, color='#1f77b4')
ax1.tick_params(axis='y', colors='#1f77b4')
ax1.set_ylim(120, 128)

# 绘制IS折线（右轴）
is_line = ax2.plot(x, is_values, 'o--', color='#ff7f0e', 
                  linewidth=2, markersize=8, label='IS')
ax2.set_ylabel('IS (Higher Better)', fontsize=12, color='#ff7f0e')
ax2.tick_params(axis='y', colors='#ff7f0e')
ax2.set_ylim(1.9, 2.4)

# 坐标轴样式设置
ax1.set_xticks(x)
ax1.set_xticklabels(config_labels, rotation=15, fontsize=10)
ax1.set_xlabel('Encoder(r1,r2)-Decoder(r4,r5) Configurations', fontsize=12)
ax1.grid(True, linestyle='--', alpha=0.6)

# 合并图例
lines = fid_line + is_line
labels = [l.get_label() for l in lines]
ax1.legend(lines, labels, loc='upper center', 
          bbox_to_anchor=(0.5, -0.15), ncol=2)

# 标注关键点
for i, (fid, is_) in enumerate(zip(fid_values, is_values)):
    ax1.text(x[i]-0.1, fid+0.3, f'{fid:.2f}', color='#1f77b4', fontsize=10)
    ax2.text(x[i]+0.1, is_-0.05, f'{is_:.2f}', color='#ff7f0e', fontsize=10)

plt.title("", fontsize=14, pad=20)
plt.tight_layout()
plt.savefig('reduction_factor_ablation.png', dpi=300)
plt.show()