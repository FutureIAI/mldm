import torch
import torch.nn as nn
import torch.nn.functional as F
from utils.metrics import ssim, lpips
from utils.schedule import get_stage_noise_params

class MLDAG:
    def __init__(self, diffusion_model, target_model, 
                 num_steps=100, alpha=0.1, beta=0.01, gamma=0.001):
        """
        多尺度潜在扩散对抗生成算法
        
        参数:
            diffusion_model: 预训练的扩散模型
            target_model: 目标攻击模型
            num_steps: 对抗样本生成步数
            alpha: 攻击损失权重
            beta: 感知损失权重
            gamma: 相似性损失权重
        """
        self.diffusion = diffusion_model
        self.target_model = target_model
        self.num_steps = num_steps
        self.alpha = alpha
        self.beta = beta
        self.gamma = gamma
        self.device = next(diffusion_model.parameters()).device
        
    def generate(self, x, target_label):
        """
        生成对抗样本
        
        参数:
            x: 原始输入图像 [B, C, H, W]
            target_label: 目标标签（用于定向攻击）
            
        返回:
            x_adv: 生成的对抗样本
        """
        # 将图像编码到潜在空间
        z_0 = self.diffusion.encode(x)
        z_t = z_0.clone().detach().requires_grad_(True)
        
        # 存储最佳对抗样本
        best_adv = None
        best_loss = float('inf')
        
        # 多阶段对抗样本优化
        for step in range(self.num_steps):
            # 获取当前阶段的噪声参数
            noise_level, schedule_params = get_stage_noise_params(step, self.num_steps)
            
            # 添加可控噪声
            noise = torch.randn_like(z_t) * noise_level
            noisy_z = z_t + noise
            
            # 解码为图像
            x_adv = self.diffusion.decode(noisy_z)
            
            # 计算损失函数
            total_loss = self._compute_loss(x, x_adv, noisy_z, target_label, schedule_params)
            
            # 梯度更新
            total_loss.backward()
            with torch.no_grad():
                grad = z_t.grad.detach()
                z_t = z_t - self._get_step_size(step) * grad.sign()
                z_t = z_t.detach().requires_grad_(True)
                
            # 更新最佳对抗样本
            current_loss = total_loss.item()
            if current_loss < best_loss:
                best_loss = current_loss
                best_adv = x_adv.detach().clone()
                
            # 打印进度
            if step % 10 == 0:
                print(f"Step {step}/{self.num_steps}, Loss: {total_loss.item():.4f}")
        
        return best_adv
    
    def _compute_loss(self, x_orig, x_adv, z_adv, target_label, schedule_params):
        """计算多损失函数"""
        # 攻击损失（非目标攻击）
        logits = self.target_model(x_adv)
        attack_loss = F.cross_entropy(logits, target_label)
        
        # 感知损失（LPIPS）
        percep_loss = lpips(x_orig, x_adv)
        
        # 结构相似性损失（SSIM）
        ssim_loss = 1 - ssim(x_orig, x_adv)
        
        # 特征空间相似性损失
        mu_orig, _ = self.diffusion.vae.encode(x_orig)
        mu_adv, _ = self.diffusion.vae.encode(x_adv)
        feature_loss = F.mse_loss(mu_orig, mu_adv)
        
        # 多阶段加权损失
        loss = (
            self.alpha * attack_loss +
            self.beta * percep_loss +
            schedule_params['ssim_weight'] * ssim_loss +
            schedule_params['feature_weight'] * feature_loss
        )
        
        return loss
    
    def _get_step_size(self, step):
        """自适应步长调整"""
        if step < self.num_steps // 3:  # 初始阶段
            return 0.1
        elif step < 2 * self.num_steps // 3:  # 中间阶段
            return 0.05
        else:  # 精细阶段
            return 0.01