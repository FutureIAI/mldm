import torch
import torch.nn as nn
import torch.nn.functional as F

class MultiScaleAttention(nn.Module):
    def __init__(self, in_channels, reduction_ratio=8):
        super().__init__()
        self.conv1x1 = nn.Conv2d(in_channels, in_channels//reduction_ratio, 1)
        self.conv3x3 = nn.Conv2d(in_channels, in_channels//reduction_ratio, 3, padding=1)
        self.conv5x5 = nn.Conv2d(in_channels, in_channels//reduction_ratio, 5, padding=2)
        self.conv7x7 = nn.Conv2d(in_channels, in_channels//reduction_ratio, 7, padding=3)
        
        self.out_conv = nn.Conv2d(4 * (in_channels//reduction_ratio), in_channels, 1)
        
    def forward(self, x):
        branch1 = F.relu(self.conv1x1(x))
        branch2 = F.relu(self.conv3x3(x))
        branch3 = F.relu(self.conv5x5(x))
        branch4 = F.relu(self.conv7x7(x))
        
        combined = torch.cat([branch1, branch2, branch3, branch4], dim=1)
        out = self.out_conv(combined)
        return x + out  # 残差连接

class MSA_UNet(nn.Module):
    def __init__(self, in_channels=3, out_channels=3, base_channels=64):
        super().__init__()
        # 编码器
        self.enc1 = nn.Sequential(
            nn.Conv2d(in_channels, base_channels, 3, padding=1),
            nn.ReLU(),
            MultiScaleAttention(base_channels)
        )
        self.enc2 = nn.Sequential(
            nn.Conv2d(base_channels, base_channels*2, 3, stride=2, padding=1),
            nn.ReLU(),
            MultiScaleAttention(base_channels*2)
        )
        self.enc3 = nn.Sequential(
            nn.Conv2d(base_channels*2, base_channels*4, 3, stride=2, padding=1),
            nn.ReLU(),
            MultiScaleAttention(base_channels*4)
        )
        
        # 瓶颈层
        self.bottleneck = nn.Sequential(
            nn.Conv2d(base_channels*4, base_channels*8, 3, padding=1),
            nn.ReLU(),
            MultiScaleAttention(base_channels*8),
            nn.Conv2d(base_channels*8, base_channels*4, 3, padding=1),
            nn.ReLU()
        )
        
        # 解码器
        self.dec1 = nn.Sequential(
            nn.ConvTranspose2d(base_channels*8, base_channels*2, 3, stride=2, padding=1, output_padding=1),
            nn.ReLU(),
            MultiScaleAttention(base_channels*2)
        )
        self.dec2 = nn.Sequential(
            nn.ConvTranspose2d(base_channels*4, base_channels, 3, stride=2, padding=1, output_padding=1),
            nn.ReLU(),
            MultiScaleAttention(base_channels)
        )
        self.out_conv = nn.Conv2d(base_channels, out_channels, 3, padding=1)
        
        # 跳跃连接
        self.skip1 = nn.Conv2d(base_channels, base_channels, 1)
        self.skip2 = nn.Conv2d(base_channels*2, base_channels*2, 1)
        
    def forward(self, x):
        # 编码路径
        enc1 = self.enc1(x)
        enc2 = self.enc2(enc1)
        enc3 = self.enc3(enc2)
        
        # 瓶颈
        bottleneck = self.bottleneck(enc3)
        
        # 解码路径 + 跳跃连接
        dec1 = self.dec1(torch.cat([bottleneck, enc3], dim=1))
        dec2 = self.dec2(torch.cat([dec1, enc2], dim=1))
        out = self.out_conv(torch.cat([dec2, enc1], dim=1))
        
        return out