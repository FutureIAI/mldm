def get_stage_noise_params(step, total_steps):
    """
    多阶段噪声调度策略
    
    参数:
        step: 当前步数
        total_steps: 总步数
        
    返回:
        noise_level: 当前噪声水平
        params: 调度参数字典
    """
    # 确定当前阶段
    if step < total_steps // 3:  # 初始阶段 (0-33%)
        stage = 'initial'
        noise_level = 0.3 - (0.3 - 0.1) * (step / (total_steps // 3))
        ssim_weight = 0.3
        feature_weight = 0.5
    elif step < 2 * total_steps // 3:  # 中间阶段 (33-66%)
        stage = 'middle'
        noise_level = 0.1 - (0.1 - 0.05) * ((step - total_steps//3) / (total_steps//3))
        ssim_weight = 0.5
        feature_weight = 0.7
    else:  # 精细阶段 (66-100%)
        stage = 'finetune'
        noise_level = 0.05 - (0.05 - 0.01) * ((step - 2*total_steps//3) / (total_steps//3))
        ssim_weight = 0.7
        feature_weight = 0.3
    
    return noise_level, {
        'stage': stage,
        'ssim_weight': ssim_weight,
        'feature_weight': feature_weight
    }