import warnings
import argparse
import torch
from easydict import EasyDict
import yaml
import os
import logging
import numpy as np
import pprint
from torch.cuda.amp import autocast
from utils.misc_helper import set_seed,get_current_time,create_logger,AverageMeter
from datasets.data_builder import build_dataloader
import copy
from samples.tsamples import UniformSampler
from samples.spaced_sample import SpacedDiffusionBeatGans
from models.sdas.create_models import create_diffusion_unet
from utils.misc_helper import ema
from utils.optimizer_helper import get_optimizer
from utils.criterion_helper import build_criterion
from utils.misc_helper import save_checkpoint
from utils.visualize import export_sdas_images
from utils.dist_helper import setup_distributed
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from contextlib import nullcontext
from utils.categories import Categories


warnings.filterwarnings('ignore')
parser = argparse.ArgumentParser(description="train diffusion models")
parser.add_argument("--config", default="experiments/{}/diffusion.yaml")
parser.add_argument("--dataset", default="MVTec-AD",choices=['MVTec-AD','BTAD'])
parser.add_argument("--local_rank", default=-1, type=int)


@torch.no_grad()
def SDAS_sample(imgs, class_labels, model, sampler):
    """
    使用SDAS模型生成样本图像
    
    参数:
    imgs: 原始图像 [batch_size, C, H, W]
    class_labels: 类别标签
    model: 扩散模型
    sampler: 扩散模型采样器
    
    返回:
    x_recon: 重建图像 (原始图像+中间状态+重建结果)
    x_gen: 生成图像 (不同强度生成的样本)
    x0_det: 确定性重建结果
    """
    device = torch.device('cuda')
    
    # 生成随机噪声 (与原始图像相同形状)
    xt = torch.randn_like(imgs).to(device)
    
    # 无引导采样 (s=0.0) - 生成正常样本
    x0_normal = sampler.p_sample_loop(model=model,
                            noise=xt,
                            device=device,
                            s=0.0,
                            model_kwargs={'y':class_labels})
    
    # 弱引导采样 (s=0.1) - 轻微异常样本
    x0_week = sampler.p_sample_loop(model=model,
                            noise=xt,
                            device=device,
                            s=0.1,
                            model_kwargs={'y':class_labels})
    
    # 强引导采样 (s=0.2) - 明显异常样本
    x0_strong = sampler.p_sample_loop(model=model,
                            noise=xt,
                            device=device,
                            s=0.2,
                            model_kwargs={'y':class_labels})
    
    # 拼接不同强度的生成图像
    x_gen = torch.cat([x0_normal, x0_week, x0_strong], dim=3)
    
    # 逆向确定性采样 - 从图像到噪声空间
    xt_det = sampler.ddim_reverse_sample_loop(
        model=model,
        x=imgs,
        clip_denoised=True,
        device=device,
        model_kwargs={'y': class_labels})['sample']
    
    # 确定性重建 - 从噪声空间重建图像
    x0_det = sampler.ddim_sample_loop(model=model,
                            noise=xt_det,
                            eta=0.0,  # 确定性采样
                            device=device,
                            model_kwargs={'y':class_labels})
    
    # 拼接重建过程图像
    x_recon = torch.cat([imgs, xt_det, x0_det], dim=3)
    
    return x_recon, x_gen, x0_det


def update_config(config, args):
    """更新配置参数"""
    # 设置数据集类别列表
    config.dataset.class_name_list = args.class_name_list
    # 设置图像尺寸参数
    config.unet.image_size = config.dataset.input_size[0]
    # 设置是否使用半精度训练
    config.unet.use_fp16 = config.trainer.use_fp16
    return config


def main():
    # 解析命令行参数
    args = parser.parse_args()
    
    # 获取当前数据集的类别列表
    args.class_name_list = Categories[args.dataset]
    # 格式化配置文件路径
    args.config = args.config.format(args.dataset)
    
    # 加载YAML配置文件
    with open(args.config) as f:
        config = EasyDict(yaml.load(f, Loader=yaml.FullLoader))
    
    # 设置分布式训练环境
    rank, world_size = setup_distributed()
    
    # 设置随机种子确保结果可复现
    set_seed(config.random_seed)
    
    # 更新配置参数
    config = update_config(config, args)
    
    # 设置实验路径和保存目录
    config.exp_path = os.path.dirname(args.config)
    config.checkpoints_path = os.path.join(config.exp_path, config.saver.checkpoints_dir)
    config.log_path = os.path.join(config.exp_path, config.saver.log_dir)
    config.vis_path = os.path.join(config.exp_path, config.saver.vis_dir)  # 可视化结果保存目录
    
    # 创建数据加载器
    train_loader, val_loader = build_dataloader(config.dataset, distributed=True)
    
    # 主进程创建必要目录
    if rank == 0:
        os.makedirs(config.checkpoints_path, exist_ok=True)
        os.makedirs(config.log_path, exist_ok=True)
        os.makedirs(config.vis_path, exist_ok=True)  # 可视化目录
        
        current_time = get_current_time()
        
        # 创建日志记录器
        logger = create_logger(
            "sdas_diffusion_logger", config.log_path + "/sdas_diffusion_{}.log".format(current_time)
        )
        # 记录配置信息
        logger.info("args: {}".format(pprint.pformat(args)))
        logger.info("config: {}".format(pprint.pformat(config)))
        logger.info("train_loader len is {}".format(len(train_loader)))
    
    # 获取本地GPU编号
    local_rank = int(os.environ["LOCAL_RANK"])
    
    # 创建扩散模型采样器
    train_sampler = SpacedDiffusionBeatGans(**config.TrainSampler)  # 训练用采样器
    test_sampler = SpacedDiffusionBeatGans(**config.TestSampler)    # 测试用采样器
    Tsampler = UniformSampler(train_sampler)  # 均匀时间步采样器
    
    # 创建扩散模型
    model = create_diffusion_unet(**config.unet).cuda()
    # 转换为同步批归一化（分布式训练专用）
    model = torch.nn.SyncBatchNorm.convert_sync_batchnorm(model)
    
    # 使用分布式数据并行包装模型
    model = DDP(
        model,
        device_ids=[local_rank],
        output_device=local_rank,
        find_unused_parameters=True,  # 允许有未使用的参数
    )
    
    # 创建指数移动平均(EMA)模型 - 提高模型稳定性
    ema_model = copy.deepcopy(model)
    ema_model.requires_grad_(False)  # 冻结EMA模型参数
    ema_model.eval()  # 设置为评估模式
    
    # 创建优化器
    optimizer = get_optimizer(model.parameters(), config.trainer.optimizer)
    
    # 训练循环
    last_epoch = 0
    for epoch in range(last_epoch, config.trainer.max_epoch):
        # 当前epoch开始时的迭代步数
        last_iter = epoch * len(train_loader)
        
        # 设置数据加载器的epoch（分布式训练需要）
        train_loader.sampler.set_epoch(epoch)
        val_loader.sampler.set_epoch(epoch)
        
        # 训练一个epoch
        train_one_epoch(
            config,
            train_loader,
            model,
            ema_model,
            optimizer,
            Tsampler,
            train_sampler,
            epoch,
            last_iter,
        )
        
        # 定期验证模型性能
        if (epoch + 1) % config.trainer.val_freq_epoch == 0:
            # 验证阶段 - 生成样本并计算损失
            fileinfos, gen_images, recon_images, avg_loss = validate(
                config, val_loader, ema_model, test_sampler, epoch + 1
            )
            
            # 导出可视化图像
            export_sdas_images(config, fileinfos, gen_images, recon_images, epoch + 1)
            
            # 主进程保存检查点
            if rank == 0:
                save_checkpoint(
                    {
                        "epoch": epoch + 1,
                        "arch": config,
                        "state_dict": ema_model.state_dict(),  # 保存EMA模型
                        "loss": avg_loss,
                    },
                    config,
                    epoch=epoch + 1
                )


def train_one_epoch(
    config,
    train_loader,
    model,
    ema_model,
    optimizer,
    Tsampler,
    sampler,
    epoch,
    start_iter,
):
    """训练一个epoch"""
    # 获取分布式训练信息
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    
    # 获取主进程的日志器
    if rank == 0:
        logger = logging.getLogger("sdas_diffusion_logger")
    
    # 初始化损失记录器
    losses = AverageMeter(config.trainer.print_freq_step)
    # 设置为训练模式
    model.train()
    
    # 遍历训练数据
    for i, input in enumerate(train_loader):
        # 当前总迭代步数
        curr_step = start_iter + i
        
        # 获取图像和标签
        imgs, class_labels = input['image'].cuda(), input['class_id'].cuda()
        
        # 扩散模型训练过程
        x_start = imgs
        # 采样时间步和权重
        t, weight = Tsampler.sample(len(x_start), x_start.device)
        
        # 使用半精度训练 (如果配置启用)
        with autocast(enabled=config.trainer.use_fp16):
            # 计算训练损失 - 核心扩散模型训练
            terms = sampler.training_losses(
                model=model, 
                x_start=x_start, 
                t=t, 
                model_kwargs={'y': class_labels}  # 传入类别条件
            )
            loss = terms['loss'].mean()  # 平均损失
        
        # 分布式训练中的损失聚合
        reduced_loss = loss.clone()
        dist.all_reduce(reduced_loss)
        reduced_loss = reduced_loss / world_size
        losses.update(reduced_loss.item())  # 更新损失记录
        
        # 设置梯度同步策略 (累积多个batch后再更新)
        step_context = model.no_sync if curr_step % config.trainer.accumulate != 0 else nullcontext
        with step_context():
            # 反向传播
            loss.backward()
            
            # 梯度裁剪 (防止梯度爆炸)
            if config.trainer.get("clip_max_norm", None):
                max_norm = config.trainer.clip_max_norm
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm)
            
            # 当完成梯度累积步数时更新参数
            if step_context == nullcontext:
                optimizer.step()  # 参数更新
                optimizer.zero_grad()  # 梯度清零
                
                # 更新EMA模型
                ema(model, ema_model, config.trainer.ema_decay)
        
        # 主进程定期打印训练信息
        if rank == 0 and (curr_step % config.trainer.print_freq_step == 0):
            logger.info(
                "Epoch: [{0}/{1}]\t"
                "Iter: [{2}/{3}]\t"
                "Loss {loss.val:.5f} ({loss.avg:.5f})\t"
                .format(
                    epoch + 1,
                    config.trainer.max_epoch,
                    curr_step + 1,
                    len(train_loader) * config.trainer.max_epoch,
                    loss=losses,
                )
            )


def validate(config, val_loader, model, test_sample, epoch):
    """模型验证"""
    # 获取分布式训练信息
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    
    # 设置为评估模式
    model.eval()
    
    # 初始化损失列表
    losses = []
    # 构建损失函数
    criterion = build_criterion(config.criterion)
    
    # 初始化可视化数据容器
    x_recon_images = []  # 重建过程图像
    x_gen_images = []   # 生成图像
    fileinfos = []       # 文件信息
    
    # 禁用梯度计算
    with torch.no_grad():
        # 遍历验证数据
        for i, input in enumerate(val_loader):
            # 获取数据和标签
            imgs, class_labels = input['image'].cuda(), input['class_id'].cuda()
            
            # 使用半精度评估 (如果配置启用)
            with autocast(enabled=config.trainer.use_fp16):
                # 使用SDAS生成样本
                x_recon, x_gen, x0_det = SDAS_sample(imgs, class_labels, model, test_sample)
            
            # 保存文件信息
            for j in range(len(input['filename'])):
                fileinfos.append({
                    "filename": str(input["filename"][j]),
                    "clsname": str(input["clsname"][j]),
                })
            
            # 收集可视化图像
            x_gen_images.append(x_gen)
            x_recon_images.append(x_recon)
            
            # 计算重建损失
            l1 = []
            for name, criterion_loss in criterion.items():
                weight = criterion_loss.weight
                # 计算原始图像与重建图像的损失
                l1.append(weight * criterion_loss({"ori": imgs, "recon": x0_det}))
            
            l1 = torch.sum(torch.stack(l1))  # 总损失
            
            # 分布式训练中的损失聚合
            dist.all_reduce(l1)
            l1 = l1 / world_size
            losses.append(l1.item())  # 记录损失
            
            # 达到验证批次数目上限则停止
            if i == config.trainer.val_batch_number:
                break
    
    # 计算平均损失
    avg_loss = np.mean(losses)
    
    # 主进程记录验证结果
    if rank == 0:
        logger = logging.getLogger("sdas_diffusion_logger")
        logger.info(" * Loss_sum {:.5f}".format(avg_loss))
    
    # 转换图像数据为numpy格式 (移回CPU)
    gen_images = torch.cat(x_gen_images, dim=0).cpu().detach().numpy()
    recon_images = torch.cat(x_recon_images, dim=0).cpu().detach().numpy()
    
    return fileinfos, gen_images, recon_images, avg_loss

if __name__ == "__main__":
    main()
