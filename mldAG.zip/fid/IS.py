# -*- coding: UTF-8 -*-
import os
import csv
import math
import torch
import torch.nn as nn
from torchvision import transforms
from torchvision.models import inception_v3
from torch.utils.data import DataLoader
from PIL import Image
import numpy as np
from scipy.stats import entropy
from tqdm import tqdm   # 进度条，可选

# ======== 配置 ========
ROOT_DIR = r"F:\experiments\BTAD\5"   # 换成你的根目录
CSV_PATH = os.path.join(ROOT_DIR, "ldm_inception_scores.csv")
BATCH_SIZE = 32
NUM_SPLITS = 10
# ======================

# ----------------- InceptionScore 封装 -----------------
class InceptionScoreCalculator:
    def __init__(self, device='cuda'):
        self.device = device
        self.model = inception_v3(pretrained=True, transform_input=True)
        self.model.eval().to(device)
        self.softmax = nn.Softmax(dim=1)

        self.transform = transforms.Compose([
            transforms.Resize((299, 299)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
        ])

    def _load_image(self, path):
        try:
            img = Image.open(path).convert("RGB")
            return self.transform(img)
        except Exception as e:
            print(f"跳过损坏文件 {path}: {e}")
            return None

    @torch.no_grad()
    def get_predictions(self, folder):
        files = [os.path.join(folder, f) for f in os.listdir(folder)
                 if f.lower().endswith((".png", ".jpg", ".jpeg",'bmp'))]

        if not files:
            return None

        # 一次性加载 & 批量推理
        dataset = [t for p in files if (t := self._load_image(p)) is not None]
        if not dataset:
            return None

        loader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=False)
        all_probs = []

        for batch in loader:
            batch = batch.to(self.device)
            preds = self.model(batch)
            probs = self.softmax(preds).cpu().numpy()
            all_probs.append(probs)

        return np.concatenate(all_probs, axis=0)

    def calculate_is(self, probs, num_splits=NUM_SPLITS):
        """
        计算 Inception Score：
          1) 把 probs 划分为 num_splits 份
          2) 每份内对每个 p(y|x) 计算 KL(p(y|x) || p(y))
          3) 求这一份上所有 KL 的平均，再 exp
          4) 最后对 num_splits 份求均值和方差
        """
        if probs is None or len(probs) == 0:
            return float("nan"), float("nan")

        N = len(probs)
        splits = min(num_splits, N)
        split_scores = []

        for k in range(splits):
            # 划分
            start = k * (N // splits)
            end   = start + (N // splits)
            part = probs[start:end]

            # 计算该 split 的 marginal p(y)
            py = np.mean(part, axis=0)

            # 逐样本计算 KL(p(y|x) || p(y))
            kl_vals = [entropy(pyx, py) for pyx in part]

            # 本 split 的 IS
            split_scores.append(math.exp(np.mean(kl_vals)))

        return float(np.mean(split_scores)), float(np.std(split_scores))

# ----------------- 主流程 -----------------
def main():
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"使用设备: {device}")

    isc = InceptionScoreCalculator(device)

    # 找到根目录下的所有一层子文件夹
    subfolders = [os.path.join(ROOT_DIR, d) for d in os.listdir(ROOT_DIR)
                  if os.path.isdir(os.path.join(ROOT_DIR, d))]
    if not subfolders:
        print("根目录下没有任何子文件夹！")
        return

    results = []
    for folder in tqdm(subfolders, desc="计算 IS"):
        probs = isc.get_predictions(folder)
        mean, std = isc.calculate_is(probs)
        folder_name = os.path.basename(folder)
        results.append((folder_name, mean, std))
        print(f"{folder_name:30s}  IS = {mean:.2f} ± {std:.2f}")

    # 保存到 CSV
    with open(CSV_PATH, "w", newline='', encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["folder", "is_mean", "is_std"])
        writer.writerows(results)

    print(f"\n已写入 {CSV_PATH}")

if __name__ == "__main__":
    main()
